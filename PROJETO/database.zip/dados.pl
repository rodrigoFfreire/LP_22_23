:- style_check(-discontiguous). 
evento(1,'engenharia biomolecular',laboratorial,5,'1-75').
horario(1,quarta-feira,14.0,17.0,3.0,p2).
turno(1,mbmrp,1,mbmrp0103).
turno(1,mbmrp,1,mbmrp0102).
turno(1,mbmrp,1,mbmrp0101).
evento(2,'engenharia biomolecular',laboratorial,5,'1-75').
horario(2,quarta-feira,14.0,17.0,3.0,p2).
turno(2,mbmrp,1,mbmrp0103).
turno(2,mbmrp,1,mbmrp0102).
turno(2,mbmrp,1,mbmrp0101).
evento(3,'engenharia biomolecular',laboratorial,3,'1-75').
horario(3,quarta-feira,9.5,11.0,1.5,p2).
turno(3,mbmrp,1,mbmrp0103).
turno(3,mbmrp,1,mbmrp0102).
turno(3,mbmrp,1,mbmrp0101).
evento(4,'engenharia biomolecular',problemas,20,'0-13').
horario(4,quarta-feira,12.0,12.5,0.5,p2).
turno(4,mbmrp,1,mbmrp0103).
turno(4,mbmrp,1,mbmrp0102).
turno(4,mbmrp,1,mbmrp0101).
evento(5,'engenharia biomolecular',teorica,25,'0-13').
horario(5,quarta-feira,11.0,12.0,1.0,p2).
turno(5,mbmrp,1,mbmrp0103).
turno(5,mbmrp,1,mbmrp0102).
turno(5,mbmrp,1,mbmrp0101).
evento(6,'engenharia biomolecular',teorica,25,'0-19').
horario(6,segunda-feira,9.0,11.0,2.0,p2).
turno(6,mbmrp,1,mbmrp0103).
turno(6,mbmrp,1,mbmrp0102).
turno(6,mbmrp,1,mbmrp0101).
evento(7,'engenharia biomolecular',seminario,20,'0-13').
horario(7,quarta-feira,12.5,13.0,0.5,p2).
turno(7,mbmrp,1,mbmrp0103).
turno(7,mbmrp,1,mbmrp0102).
turno(7,mbmrp,1,mbmrp0101).
evento(8,'sistemas digitais',teorica,123,a4).
horario(8,terca-feira,9.5,11.5,2.0,p2).
turno(8,lee,1,lee0103).
turno(8,leti,1,leti0103).
turno(8,leti,1,leti0102).
turno(8,leti,1,leti0101).
turno(8,lee,1,lee0102).
turno(8,lee,1,lee0101).
evento(9,'sistemas digitais',teorica,123,a2).
horario(9,quinta-feira,10.0,12.0,2.0,p2).
turno(9,lee,1,lee0103).
turno(9,leti,1,leti0103).
turno(9,leti,1,leti0102).
turno(9,leti,1,leti0101).
turno(9,lee,1,lee0102).
turno(9,lee,1,lee0101).
evento(10,'sistemas digitais',laboratorial,18,'1-62').
horario(10,sexta-feira,8.0,10.0,2.0,p2).
turno(10,lee,1,lee0102).
turno(10,lee,1,lee0101).
evento(11,'sistemas digitais',problemas,35,'0-16').
horario(11,quinta-feira,13.0,15.0,2.0,p2).
turno(11,lee,1,lee0103).
turno(11,leti,1,leti0103).
turno(11,leti,1,leti0101).
evento(12,'sistemas digitais',laboratorial,18,'1-62').
horario(12,sexta-feira,12.5,14.5,2.0,p2).
turno(12,leti,1,leti0101).
evento(13,'sistemas digitais',laboratorial,18,'1-62').
horario(13,quinta-feira,13.0,15.0,2.0,p2).
turno(13,leti,1,leti0102).
evento(14,'sistemas digitais',laboratorial,18,semSala).
horario(14,terca-feira,11.5,13.5,2.0,p2).
turno(14,lee,1,lee0103).
evento(15,'sistemas digitais',problemas,40,'0-16').
horario(15,quinta-feira,15.0,17.0,2.0,p2).
turno(15,lee,1,lee0103).
turno(15,lee,1,lee0102).
turno(15,lee,1,lee0101).
evento(16,'sistemas digitais',laboratorial,17,'1-62').
horario(16,quarta-feira,10.0,12.0,2.0,p2).
turno(16,leti,1,leti0103).
evento(17,'sistemas digitais',problemas,37,'0-23').
horario(17,quarta-feira,10.0,12.0,2.0,p2).
turno(17,leti,1,leti0102).
turno(17,leti,1,leti0101).
evento(18,'sistemas digitais',laboratorial,18,'1-62').
horario(18,terca-feira,14.0,16.0,2.0,p2).
turno(18,leti,1,leti0103).
turno(18,leti,1,leti0102).
turno(18,leti,1,leti0101).
evento(19,'engenharia de celulas e tecidos','teorico-pratica',16,'0-13').
horario(19,segunda-feira,17.5,19.5,2.0,p1).
turno(19,mbmrp,1,mbmrp0103).
turno(19,mbmrp,1,mbmrp0102).
turno(19,mbmrp,1,mbmrp0101).
evento(20,'engenharia de celulas e tecidos',laboratorial,4,'1-15').
horario(20,quinta-feira,10.0,12.0,2.0,p1).
turno(20,mbmrp,1,mbmrp0101).
evento(21,'engenharia de celulas e tecidos',seminario,16,'0-25').
horario(21,quarta-feira,9.5,11.5,2.0,p1).
turno(21,mbmrp,1,mbmrp0103).
turno(21,mbmrp,1,mbmrp0102).
turno(21,mbmrp,1,mbmrp0101).
evento(22,'engenharia de celulas e tecidos',seminario,16,'1-11').
horario(22,terca-feira,9.5,11.0,1.5,p1).
turno(22,mbmrp,1,mbmrp0103).
turno(22,mbmrp,1,mbmrp0102).
turno(22,mbmrp,1,mbmrp0101).
evento(23,'engenharia de celulas e tecidos',laboratorial,10,'1-75').
horario(23,terca-feira,9.5,11.0,1.5,p1).
turno(23,mbmrp,1,mbmrp0103).
turno(23,mbmrp,1,mbmrp0102).
turno(23,mbmrp,1,mbmrp0101).
evento(24,'engenharia de celulas e tecidos',laboratorial,10,'1-75').
horario(24,terca-feira,11.0,12.5,1.5,p1).
turno(24,mbmrp,1,mbmrp0103).
turno(24,mbmrp,1,mbmrp0102).
turno(24,mbmrp,1,mbmrp0101).
evento(25,'engenharia de celulas e tecidos',laboratorial,10,'1-75').
horario(25,quinta-feira,12.0,13.5,1.5,p1).
turno(25,mbmrp,1,mbmrp0103).
turno(25,mbmrp,1,mbmrp0102).
turno(25,mbmrp,1,mbmrp0101).
evento(26,'engenharia de celulas e tecidos',laboratorial,10,'0-15').
horario(26,segunda-feira,10.0,12.0,2.0,p1).
turno(26,mbmrp,1,mbmrp0103).
turno(26,mbmrp,1,mbmrp0102).
turno(26,mbmrp,1,mbmrp0101).
evento(27,'engenharia de celulas e tecidos',teorica,16,'0-19').
horario(27,quinta-feira,13.5,15.5,2.0,p1).
turno(27,mbmrp,1,mbmrp0103).
turno(27,mbmrp,1,mbmrp0102).
turno(27,mbmrp,1,mbmrp0101).
evento(28,'engenharia de celulas e tecidos',teorica,16,'0-13').
horario(28,quinta-feira,11.5,12.5,1.0,p1).
turno(28,mbmrp,1,mbmrp0103).
turno(28,mbmrp,1,mbmrp0102).
turno(28,mbmrp,1,mbmrp0101).
evento(29,'engenharia de celulas e tecidos',teorica,16,'0-13').
horario(29,quinta-feira,9.5,11.5,2.0,p1).
turno(29,mbmrp,1,mbmrp0103).
turno(29,mbmrp,1,mbmrp0102).
turno(29,mbmrp,1,mbmrp0101).
evento(30,'engenharia de celulas e tecidos',teorica,16,'0-13').
horario(30,terca-feira,13.5,15.5,2.0,p1).
turno(30,mbmrp,1,mbmrp0103).
turno(30,mbmrp,1,mbmrp0102).
turno(30,mbmrp,1,mbmrp0101).
evento(31,'contabilidade financeira e de gestao',teorica,87,a3).
horario(31,quarta-feira,11.5,13.0,1.5,p1).
turno(31,legi,2,legi0205).
turno(31,legi,2,legi0202).
turno(31,legi,2,legi0204).
turno(31,legi,2,legi0201).
turno(31,legi,2,legi0203).
evento(32,'contabilidade financeira e de gestao',teorica,87,'0-65').
horario(32,segunda-feira,14.0,15.5,1.5,p1).
turno(32,legi,2,legi0205).
turno(32,legi,2,legi0202).
turno(32,legi,2,legi0204).
turno(32,legi,2,legi0201).
turno(32,legi,2,legi0203).
evento(33,'contabilidade financeira e de gestao','teorico-pratica',24,'1-4').
horario(33,segunda-feira,15.5,17.5,2.0,p1).
turno(33,legi,2,legi0202).
turno(33,legi,2,legi0203).
evento(34,'contabilidade financeira e de gestao','teorico-pratica',29,'1-4').
horario(34,segunda-feira,11.0,13.0,2.0,p1).
turno(34,legi,2,legi0204).
turno(34,legi,2,legi0201).
evento(35,'contabilidade financeira e de gestao','teorico-pratica',30,'0-25').
horario(35,segunda-feira,17.5,19.5,2.0,p1).
turno(35,legi,2,legi0205).
evento(36,econometria,laboratorial,25,'1-4').
horario(36,sexta-feira,16.5,18.0,1.5,p1_2).
turno(36,megi,1,megi0101).
evento(37,econometria,teorica,79,a2).
horario(37,terca-feira,14.0,16.0,2.0,p1_2).
turno(37,megi,1,megi0102).
evento(38,econometria,laboratorial,24,'1-11').
horario(38,terca-feira,16.0,17.5,1.5,p1).
turno(38,megi,1,megi0102).
evento(39,econometria,laboratorial,24,'1-3').
horario(39,terca-feira,16.0,17.5,1.5,p2).
turno(39,megi,1,megi0102).
evento(40,econometria,laboratorial,25,'0-73').
horario(40,terca-feira,12.5,14.0,1.5,p1_2).
turno(40,megi,1,megi0103).
evento(41,'bioengenharia e empreendedorismo','teorico-pratica',19,'0-16').
horario(41,sexta-feira,15.0,17.0,2.0,p1).
turno(41,mbmrp,1,mbmrp0103).
turno(41,mbmrp,1,mbmrp0102).
turno(41,mbmrp,1,mbmrp0101).
evento(42,'bioengenharia e empreendedorismo','teorico-pratica',19,'0-25').
horario(42,segunda-feira,13.5,15.5,2.0,p1).
turno(42,mbmrp,1,mbmrp0103).
turno(42,mbmrp,1,mbmrp0102).
turno(42,mbmrp,1,mbmrp0101).
evento(43,'genomica funcional e comparativa',laboratorial,12,'1-15').
horario(43,quinta-feira,8.0,11.0,3.0,p2).
turno(43,mbmrp,1,mbmrp0103).
turno(43,mbmrp,1,mbmrp0102).
turno(43,mbmrp,1,mbmrp0101).
evento(44,'genomica funcional e comparativa',teorica,13,a4).
horario(44,terca-feira,14.0,16.0,2.0,p2).
turno(44,mbmrp,1,mbmrp0103).
turno(44,mbmrp,1,mbmrp0102).
turno(44,mbmrp,1,mbmrp0101).
evento(45,'genomica funcional e comparativa',teorica,13,'0-13').
horario(45,quinta-feira,14.0,16.0,2.0,p2).
turno(45,mbmrp,1,mbmrp0103).
turno(45,mbmrp,1,mbmrp0102).
turno(45,mbmrp,1,mbmrp0101).
evento(46,'tecnologia e sociedade',seminario,28,'0-75').
horario(46,quinta-feira,14.5,16.0,1.5,p2).
evento(47,'tecnologia e sociedade',teorica,100,a2).
horario(47,quarta-feira,16.0,18.0,2.0,p2).
evento(48,'tecnologia e sociedade',seminario,25,'0-75').
horario(48,quinta-feira,13.0,14.5,1.5,p2).
evento(49,'redes de computadores',laboratorial,25,'0-25').
horario(49,segunda-feira,11.0,12.5,1.5,indeterminado).
turno(49,'leic-t',3,leic-t0302).
evento(50,'redes de computadores',laboratorial,25,'1-17').
horario(50,segunda-feira,11.0,12.5,1.5,p2).
turno(50,'leic-t',3,leic-t0302).
evento(51,'redes de computadores',laboratorial,25,'1-17').
horario(51,quarta-feira,11.0,12.5,1.5,p2).
turno(51,'leic-t',3,leic-t0302).
evento(52,'redes de computadores',laboratorial,24,'0-15').
horario(52,terca-feira,8.0,9.5,1.5,indeterminado).
turno(52,'leic-t',3,leic-t0304).
evento(53,'redes de computadores',laboratorial,24,'1-17').
horario(53,sexta-feira,9.0,10.5,1.5,p2).
turno(53,'leic-t',3,leic-t0304).
evento(54,'redes de computadores',laboratorial,24,'1-17').
horario(54,terca-feira,8.0,9.5,1.5,p2).
turno(54,'leic-t',3,leic-t0304).
evento(55,'redes de computadores',laboratorial,29,'0-17').
horario(55,terca-feira,8.0,9.5,1.5,indeterminado).
turno(55,'leic-t',3,leic-t0301).
evento(56,'redes de computadores',laboratorial,29,'0-14').
horario(56,sexta-feira,9.0,10.5,1.5,p2).
turno(56,'leic-t',3,leic-t0301).
evento(57,'redes de computadores',laboratorial,29,'1-19').
horario(57,terca-feira,8.0,9.5,1.5,p2).
turno(57,'leic-t',3,leic-t0301).
evento(58,'redes de computadores',teorica,101,a3).
horario(58,quarta-feira,8.0,9.0,1.0,p2).
turno(58,'leic-t',3,leic-t0302).
turno(58,'leic-t',3,leic-t0301).
turno(58,'leic-t',3,leic-t0304).
turno(58,'leic-t',3,leic-t0303).
evento(59,'redes de computadores',teorica,101,a3).
horario(59,segunda-feira,8.0,9.0,1.0,p2).
turno(59,'leic-t',3,leic-t0302).
turno(59,'leic-t',3,leic-t0301).
turno(59,'leic-t',3,leic-t0304).
turno(59,'leic-t',3,leic-t0303).
evento(60,'redes de computadores',teorica,101,a4).
horario(60,sexta-feira,8.0,9.0,1.0,p2).
turno(60,'leic-t',3,leic-t0302).
turno(60,'leic-t',3,leic-t0301).
turno(60,'leic-t',3,leic-t0304).
turno(60,'leic-t',3,leic-t0303).
evento(61,'redes de computadores',teorica,101,a2).
horario(61,terca-feira,9.5,10.5,1.0,p2).
turno(61,'leic-t',3,leic-t0302).
turno(61,'leic-t',3,leic-t0301).
turno(61,'leic-t',3,leic-t0304).
turno(61,'leic-t',3,leic-t0303).
evento(62,'redes de computadores',laboratorial,25,'1-19').
horario(62,quarta-feira,11.0,12.5,1.5,p2).
turno(62,'leic-t',3,leic-t0303).
evento(63,'redes de computadores',laboratorial,25,'1-19').
horario(63,segunda-feira,11.0,12.5,1.5,p2).
turno(63,'leic-t',3,leic-t0303).
evento(64,'projecto e realizacao de filtros',teorica,0,'1-12').
horario(64,quarta-feira,17.0,18.5,1.5,p1).
evento(65,'fisica ii','teorico-pratica',40,'0-15').
horario(65,terca-feira,14.0,15.5,1.5,p1).
turno(65,'leic-t',2,leic-t0206).
turno(65,'leic-t',2,leic-t0202).
evento(66,'fisica ii','teorico-pratica',40,'0-16').
horario(66,segunda-feira,14.0,15.5,1.5,p1).
turno(66,'leic-t',2,leic-t0206).
turno(66,'leic-t',2,leic-t0202).
evento(67,'fisica ii','teorico-pratica',38,'0-9').
horario(67,segunda-feira,15.5,17.0,1.5,p1).
turno(67,'leic-t',2,leic-t0201).
evento(68,'fisica ii','teorico-pratica',38,'0-16').
horario(68,terca-feira,16.5,18.0,1.5,p1).
turno(68,'leic-t',2,leic-t0201).
evento(69,'fisica ii','teorico-pratica',25,'0-9').
horario(69,segunda-feira,14.0,15.5,1.5,p1).
turno(69,'leic-t',2,leic-t0205).
turno(69,'leic-t',2,leic-t0203).
evento(70,'fisica ii','teorico-pratica',25,'0-9').
horario(70,quinta-feira,15.5,17.0,1.5,p1).
turno(70,'leic-t',2,leic-t0205).
turno(70,'leic-t',2,leic-t0203).
evento(71,'fisica ii',teorica,122,a1).
horario(71,quarta-feira,15.5,17.5,2.0,p1).
turno(71,'leic-t',2,leic-t0206).
turno(71,'leic-t',2,leic-t0205).
turno(71,'leic-t',2,leic-t0202).
turno(71,'leic-t',2,leic-t0204).
turno(71,'leic-t',2,leic-t0201).
turno(71,'leic-t',2,leic-t0203).
evento(72,'fisica ii',teorica,122,a2).
horario(72,sexta-feira,16.5,18.5,2.0,p1).
turno(72,'leic-t',2,leic-t0206).
turno(72,'leic-t',2,leic-t0205).
turno(72,'leic-t',2,leic-t0202).
turno(72,'leic-t',2,leic-t0204).
turno(72,'leic-t',2,leic-t0201).
turno(72,'leic-t',2,leic-t0203).
evento(73,'fisica ii','teorico-pratica',17,'1-11').
horario(73,segunda-feira,15.5,17.0,1.5,p1).
turno(73,'leic-t',2,leic-t0204).
evento(74,'fisica ii','teorico-pratica',17,'0-15').
horario(74,terca-feira,16.5,18.0,1.5,p1).
turno(74,'leic-t',2,leic-t0204).
evento(75,'aplicacoes e computacao para a internet das coisas',teorica,17,'0-19').
horario(75,terca-feira,13.5,15.5,2.0,p2).
turno(75,meti,1,merc0101).
turno(75,'meic-t',1,meic-t0101).
evento(76,'aplicacoes e computacao para a internet das coisas',teorica,17,'0-19').
horario(76,quarta-feira,9.5,11.5,2.0,p2).
turno(76,meti,1,merc0101).
turno(76,'meic-t',1,meic-t0101).
evento(77,'aplicacoes e computacao para a internet das coisas',laboratorial,19,'1-17').
horario(77,terca-feira,15.5,18.5,3.0,p2).
turno(77,meti,1,merc0101).
turno(77,'meic-t',1,meic-t0101).
evento(78,'calculo diferencial e integral i','teorico-pratica',86,a1).
horario(78,quarta-feira,8.0,10.0,2.0,p1_2).
turno(78,leti,1,leti0103).
turno(78,leti,1,leti0102).
turno(78,leti,1,leti0101).
evento(79,'calculo diferencial e integral i','teorico-pratica',86,a2).
horario(79,sexta-feira,8.0,10.0,2.0,p1_2).
turno(79,leti,1,leti0103).
turno(79,leti,1,leti0102).
turno(79,leti,1,leti0101).
evento(80,'competencias transversais mee ii',seminario,14,'1-11').
horario(80,sexta-feira,16.0,18.0,2.0,indeterminado).
turno(80,mee,1,mee0101).
evento(81,'competencias transversais mee ii',seminario,14,'1-3').
horario(81,sexta-feira,16.0,18.0,2.0,p2).
turno(81,mee,1,mee0101).
evento(82,'metodos estatisticos multivariados para engenharia e gestao',problemas,30,'0-15').
horario(82,quarta-feira,11.5,13.0,1.5,p1).
turno(82,megi,2,megi0202).
turno(82,megi,2,megi0201).
evento(83,'metodos estatisticos multivariados para engenharia e gestao',problemas,30,'0-16').
horario(83,quarta-feira,11.5,13.0,1.5,p2).
turno(83,megi,2,megi0202).
turno(83,megi,2,megi0201).
evento(84,'metodos estatisticos multivariados para engenharia e gestao',teorica,30,'0-16').
horario(84,quarta-feira,9.0,11.0,2.0,p1_2).
turno(84,megi,2,megi0202).
turno(84,megi,2,megi0201).
evento(85,'fisica i','teorico-pratica',7,'0-15').
horario(85,quarta-feira,14.0,15.5,1.5,p1).
turno(85,legi,2,legi0205).
turno(85,legi,2,legi0202).
turno(85,legi,2,legi0204).
turno(85,legi,2,legi0201).
turno(85,legi,2,legi0203).
evento(86,'fisica i','teorico-pratica',2,'0-15').
horario(86,quinta-feira,17.5,19.0,1.5,p1).
turno(86,legi,2,legi0205).
turno(86,legi,2,legi0202).
turno(86,legi,2,legi0204).
turno(86,legi,2,legi0201).
turno(86,legi,2,legi0203).
evento(87,'fisica i',teorica,9,a3).
horario(87,segunda-feira,18.0,20.0,2.0,p1).
turno(87,legi,2,legi0205).
turno(87,legi,2,legi0202).
turno(87,legi,2,legi0204).
turno(87,legi,2,legi0201).
turno(87,legi,2,legi0203).
evento(88,'fisica i',teorica,9,semSala).
horario(88,terca-feira,14.0,16.0,2.0,p1).
turno(88,legi,2,legi0205).
turno(88,legi,2,legi0202).
turno(88,legi,2,legi0204).
turno(88,legi,2,legi0201).
turno(88,legi,2,legi0203).
evento(89,'complementos de investigacao operacional','teorico-pratica',51,a1).
horario(89,quinta-feira,15.0,17.0,2.0,p1).
turno(89,megi,1,megi0101).
turno(89,megi,1,megi0103).
evento(90,'complementos de investigacao operacional','teorico-pratica',51,a3).
horario(90,sexta-feira,13.0,15.0,2.0,p1).
turno(90,megi,1,megi0101).
turno(90,megi,1,megi0103).
evento(91,'complementos de investigacao operacional','teorico-pratica',51,a5).
horario(91,segunda-feira,17.5,19.5,2.0,p1).
turno(91,megi,1,megi0101).
turno(91,megi,1,megi0103).
evento(92,'complementos de investigacao operacional','teorico-pratica',25,a3).
horario(92,quinta-feira,17.0,19.0,2.0,p1).
turno(92,megi,1,megi0102).
evento(93,'complementos de investigacao operacional','teorico-pratica',25,'0-9').
horario(93,sexta-feira,15.0,17.0,2.0,p1).
turno(93,megi,1,megi0102).
evento(94,'complementos de investigacao operacional','teorico-pratica',25,a1).
horario(94,segunda-feira,13.5,15.5,2.0,p1).
turno(94,megi,1,megi0102).
evento(95,'algebra linear','teorico-pratica',54,a5).
horario(95,terca-feira,11.5,13.5,2.0,p2).
turno(95,'leic-t',1,leic-t0104).
turno(95,'leic-t',1,leic-t0102).
turno(95,'leic-t',1,leic-t0106).
evento(96,'algebra linear','teorico-pratica',54,a5).
horario(96,sexta-feira,10.0,12.0,2.0,p1_2).
turno(96,'leic-t',1,leic-t0104).
turno(96,'leic-t',1,leic-t0102).
turno(96,'leic-t',1,leic-t0106).
evento(97,'algebra linear','teorico-pratica',54,a5).
horario(97,quarta-feira,10.5,12.5,2.0,p1).
turno(97,'leic-t',1,leic-t0104).
turno(97,'leic-t',1,leic-t0102).
turno(97,'leic-t',1,leic-t0106).
evento(98,'algebra linear','teorico-pratica',59,'1-2').
horario(98,terca-feira,8.0,10.0,2.0,p1).
turno(98,'leic-t',1,leic-t0107).
turno(98,'leic-t',1,leic-t0105).
turno(98,'leic-t',1,leic-t0103).
turno(98,'leic-t',1,leic-t0101).
evento(99,'algebra linear','teorico-pratica',59,'1-22').
horario(99,segunda-feira,8.0,10.0,2.0,p1_2).
turno(99,'leic-t',1,leic-t0107).
turno(99,'leic-t',1,leic-t0105).
turno(99,'leic-t',1,leic-t0103).
turno(99,'leic-t',1,leic-t0101).
evento(100,'algebra linear','teorico-pratica',59,'1-22').
horario(100,terca-feira,8.0,10.0,2.0,p1_2).
turno(100,'leic-t',1,leic-t0107).
turno(100,'leic-t',1,leic-t0105).
turno(100,'leic-t',1,leic-t0103).
turno(100,'leic-t',1,leic-t0101).
evento(101,'processamento e recuperacao de informacao',laboratorial,3,'1-17').
horario(101,quarta-feira,16.0,17.5,1.5,p1).
turno(101,meti,1,merc0101).
turno(101,'meic-t',1,meic-t0101).
evento(102,'processamento e recuperacao de informacao',laboratorial,3,'1-15').
horario(102,terca-feira,13.0,14.5,1.5,p1).
turno(102,meti,1,merc0101).
turno(102,'meic-t',1,meic-t0101).
evento(103,'processamento e recuperacao de informacao',laboratorial,4,'1-17').
horario(103,segunda-feira,12.0,13.5,1.5,p1).
turno(103,meti,1,merc0101).
turno(103,'meic-t',1,meic-t0101).
evento(104,'processamento e recuperacao de informacao',laboratorial,4,'1-15').
horario(104,sexta-feira,11.0,12.5,1.5,p1).
turno(104,meti,1,merc0101).
turno(104,'meic-t',1,meic-t0101).
evento(105,'processamento e recuperacao de informacao',teorica,10,'0-19').
horario(105,segunda-feira,18.0,20.0,2.0,p1).
turno(105,meti,1,merc0101).
turno(105,'meic-t',1,meic-t0101).
evento(106,'processamento e recuperacao de informacao',teorica,10,'0-19').
horario(106,quarta-feira,10.5,12.5,2.0,p1).
turno(106,meti,1,merc0101).
turno(106,'meic-t',1,meic-t0101).
evento(107,'introducao a engenharia de telecomunicacoes e informatica','teorico-pratica',41,a3).
horario(107,terca-feira,10.0,11.5,1.5,p1).
turno(107,leti,1,leti0103).
turno(107,leti,1,leti0102).
turno(107,leti,1,leti0101).
evento(108,'introducao a engenharia de telecomunicacoes e informatica','teorico-pratica',41,a5).
horario(108,quinta-feira,10.0,11.5,1.5,p1).
turno(108,leti,1,leti0103).
turno(108,leti,1,leti0102).
turno(108,leti,1,leti0101).
evento(109,'lingua natural',laboratorial,15,'0-15').
horario(109,segunda-feira,8.0,9.5,1.5,p1).
turno(109,'meic-t',1,meic-t0101).
evento(110,'lingua natural',laboratorial,15,'0-15').
horario(110,sexta-feira,11.0,12.5,1.5,p1).
turno(110,'meic-t',1,meic-t0101).
evento(111,'lingua natural',laboratorial,18,'0-16').
horario(111,segunda-feira,12.5,14.0,1.5,p1).
turno(111,'meic-t',1,meic-t0101).
evento(112,'lingua natural',laboratorial,18,'0-15').
horario(112,sexta-feira,13.5,15.0,1.5,p1).
turno(112,'meic-t',1,meic-t0101).
evento(113,'lingua natural',teorica,30,'0-16').
horario(113,segunda-feira,9.5,11.5,2.0,p1).
turno(113,'meic-t',1,meic-t0101).
evento(114,'lingua natural',teorica,30,'0-16').
horario(114,quinta-feira,13.5,15.5,2.0,p1).
turno(114,'meic-t',1,meic-t0101).
evento(115,'sistemas eletronicos integrados',laboratorial,5,'1-29').
horario(115,terca-feira,10.0,11.5,1.5,p1).
turno(115,mee,1,mee0101).
evento(116,'sistemas eletronicos integrados',laboratorial,5,'0-27').
horario(116,segunda-feira,11.0,12.5,1.5,p1).
turno(116,mee,1,mee0101).
evento(117,'sistemas eletronicos integrados','teorico-pratica',5,'0-73').
horario(117,segunda-feira,9.0,11.0,2.0,p1).
turno(117,mee,1,mee0101).
evento(118,'sistemas eletronicos integrados','teorico-pratica',5,'0-16').
horario(118,terca-feira,8.0,10.0,2.0,p1).
turno(118,mee,1,mee0101).
evento(119,'eletromagnetismo e optica','teorico-pratica',32,'0-17').
horario(119,terca-feira,15.5,17.0,1.5,p1).
turno(119,leti,2,leti0202).
turno(119,leti,2,leti0204).
evento(120,'eletromagnetismo e optica','teorico-pratica',32,'0-25').
horario(120,quinta-feira,15.0,16.5,1.5,p1).
turno(120,leti,2,leti0202).
turno(120,leti,2,leti0204).
evento(121,'eletromagnetismo e optica','teorico-pratica',35,'0-25').
horario(121,terca-feira,13.0,14.5,1.5,p1).
turno(121,leti,2,leti0201).
turno(121,leti,2,leti0203).
evento(122,'eletromagnetismo e optica','teorico-pratica',35,'0-25').
horario(122,quarta-feira,16.5,18.0,1.5,p1).
turno(122,leti,2,leti0201).
turno(122,leti,2,leti0203).
evento(123,'eletromagnetismo e optica',teorica,68,a4).
horario(123,quarta-feira,14.5,16.5,2.0,p1).
turno(123,leti,2,leti0201).
turno(123,leti,2,leti0203).
turno(123,leti,2,leti0202).
turno(123,leti,2,leti0204).
evento(124,'eletromagnetismo e optica',teorica,68,a3).
horario(124,segunda-feira,15.0,17.0,2.0,p1).
turno(124,leti,2,leti0201).
turno(124,leti,2,leti0203).
turno(124,leti,2,leti0202).
turno(124,leti,2,leti0204).
evento(125,'introducao a engenharia informatica',seminario,106,a2).
horario(125,quarta-feira,15.0,18.0,3.0,p1).
turno(125,'leic-t',1,leic-t0107).
turno(125,'leic-t',1,leic-t0105).
turno(125,'leic-t',1,leic-t0104).
turno(125,'leic-t',1,leic-t0103).
turno(125,'leic-t',1,leic-t0101).
turno(125,'leic-t',1,leic-t0102).
turno(125,'leic-t',1,leic-t0106).
evento(126,'fundamentos de sistemas de informacao',seminario,29,'1-3').
horario(126,segunda-feira,14.0,17.0,3.0,p1).
turno(126,mee,2,mee0201).
turno(126,'meic-t',1,meic-t0101).
evento(127,'projecto teste e fiabilidade de sistemas electronicos','teorico-pratica',5,'0-9').
horario(127,sexta-feira,10.5,12.5,2.0,indeterminado).
turno(127,mee,2,mee0201).
evento(128,'projecto teste e fiabilidade de sistemas electronicos','teorico-pratica',5,'0-9').
horario(128,quarta-feira,10.0,12.0,2.0,p2).
turno(128,mee,2,mee0201).
evento(129,'projecto teste e fiabilidade de sistemas electronicos','teorico-pratica',5,'0-9').
horario(129,segunda-feira,9.5,11.5,2.0,p2).
turno(129,mee,2,mee0201).
evento(130,'projecto teste e fiabilidade de sistemas electronicos',laboratorial,5,'1-64').
horario(130,quarta-feira,12.0,13.5,1.5,p2).
turno(130,mee,2,mee0201).
evento(131,'projecto teste e fiabilidade de sistemas electronicos',laboratorial,5,'1-64').
horario(131,sexta-feira,13.5,15.0,1.5,indeterminado).
turno(131,mee,2,mee0201).
evento(132,'projecto teste e fiabilidade de sistemas electronicos',laboratorial,5,'1-60').
horario(132,segunda-feira,11.5,13.0,1.5,p2).
turno(132,mee,2,mee0201).
evento(133,'gestao industrial e ambiente',pratica,30,'1-4').
horario(133,quarta-feira,10.0,11.5,1.5,p2).
turno(133,legi,3,legi0301).
turno(133,legi,3,legi0305).
turno(133,legi,3,legi0302).
evento(134,'gestao industrial e ambiente',pratica,30,'1-22').
horario(134,sexta-feira,9.0,10.5,1.5,p2).
turno(134,legi,3,legi0301).
turno(134,legi,3,legi0305).
turno(134,legi,3,legi0302).
evento(135,'gestao industrial e ambiente',teorica,69,a1).
horario(135,segunda-feira,12.0,14.0,2.0,p2).
turno(135,legi,3,legi0303).
turno(135,legi,3,legi0304).
turno(135,legi,3,legi0301).
turno(135,legi,3,legi0305).
turno(135,legi,3,legi0302).
evento(136,'gestao industrial e ambiente',teorica,69,a1).
horario(136,quarta-feira,11.5,13.5,2.0,p2).
turno(136,legi,3,legi0303).
turno(136,legi,3,legi0304).
turno(136,legi,3,legi0301).
turno(136,legi,3,legi0305).
turno(136,legi,3,legi0302).
evento(137,'gestao industrial e ambiente',pratica,35,'1-4').
horario(137,sexta-feira,10.5,12.0,1.5,p2).
turno(137,legi,3,legi0303).
turno(137,legi,3,legi0304).
evento(138,'gestao industrial e ambiente',pratica,35,'0-75').
horario(138,segunda-feira,10.5,12.0,1.5,p2).
turno(138,legi,3,legi0303).
turno(138,legi,3,legi0304).
evento(139,'gestao de armazens e materiais',laboratorial,27,'0-15').
horario(139,quarta-feira,16.0,17.5,1.5,p1).
turno(139,megi,2,megi0202).
evento(140,'gestao de armazens e materiais',laboratorial,27,'0-15').
horario(140,quarta-feira,17.5,19.0,1.5,p1).
turno(140,megi,2,megi0202).
evento(141,'gestao de armazens e materiais','teorico-pratica',55,a2).
horario(141,segunda-feira,14.5,16.0,1.5,p1).
turno(141,megi,2,megi0202).
turno(141,megi,2,megi0201).
evento(142,'gestao de armazens e materiais','teorico-pratica',55,a3).
horario(142,quarta-feira,14.5,16.0,1.5,p1).
turno(142,megi,2,megi0202).
turno(142,megi,2,megi0201).
evento(143,'gestao de armazens e materiais','teorico-pratica',55,'1-2').
horario(143,segunda-feira,14.5,16.0,1.5,p1).
turno(143,megi,2,megi0202).
turno(143,megi,2,megi0201).
evento(144,'gestao de armazens e materiais',laboratorial,26,'0-17').
horario(144,quarta-feira,17.5,19.0,1.5,p1).
turno(144,megi,2,megi0201).
evento(145,'gestao de armazens e materiais',laboratorial,26,'0-17').
horario(145,quarta-feira,16.0,17.5,1.5,p1).
turno(145,megi,2,megi0201).
evento(146,'analise e integracao de dados',laboratorial,7,'0-21').
horario(146,quinta-feira,14.0,15.5,1.5,p1).
turno(146,'meic-t',1,meic-t0101).
evento(147,'analise e integracao de dados',laboratorial,7,'0-14').
horario(147,segunda-feira,10.5,12.0,1.5,p1).
turno(147,'meic-t',1,meic-t0101).
evento(148,'analise e integracao de dados',teorica,32,'0-19').
horario(148,segunda-feira,14.0,16.0,2.0,p1).
turno(148,'meic-t',1,meic-t0101).
evento(149,'analise e integracao de dados',teorica,32,'0-19').
horario(149,quinta-feira,10.0,12.0,2.0,p1).
turno(149,'meic-t',1,meic-t0101).
evento(150,'analise e integracao de dados',laboratorial,13,'1-29').
horario(150,quinta-feira,14.0,15.5,1.5,p1).
turno(150,'meic-t',1,meic-t0101).
evento(151,'analise e integracao de dados',laboratorial,13,'1-19').
horario(151,segunda-feira,10.5,12.0,1.5,p1).
turno(151,'meic-t',1,meic-t0101).
evento(152,gestao,pratica,33,'0-23').
horario(152,quinta-feira,11.0,12.5,1.5,p2).
turno(152,'leic-t',1,leic-t0101).
evento(153,gestao,teorica,70,a5).
horario(153,segunda-feira,10.0,12.0,2.0,p2).
turno(153,'leic-t',2,leic-t0205).
turno(153,leti,1,leti0101).
turno(153,'leic-t',1,leic-t0103).
turno(153,'leic-t',2,leic-t0201).
turno(153,leti,3,leti0303).
turno(153,leti,3,leti0302).
evento(154,gestao,pratica,40,'0-23').
horario(154,quarta-feira,12.0,13.5,1.5,p2).
turno(154,'leic-t',2,leic-t0206).
turno(154,leti,1,leti0103).
turno(154,leti,3,leti0301).
evento(155,gestao,pratica,39,'0-15').
horario(155,quinta-feira,12.5,14.0,1.5,p2).
turno(155,'leic-t',2,leic-t0205).
turno(155,leti,1,leti0101).
turno(155,'leic-t',1,leic-t0101).
turno(155,leti,3,leti0301).
evento(156,gestao,pratica,40,'1-24').
horario(156,terca-feira,14.0,15.5,1.5,p2).
turno(156,'leic-t',1,leic-t0105).
turno(156,'leic-t',1,leic-t0102).
turno(156,leti,3,leti0301).
evento(157,gestao,pratica,39,'0-15').
horario(157,sexta-feira,12.5,14.0,1.5,p2).
turno(157,leti,1,leti0102).
turno(157,'leic-t',1,leic-t0101).
turno(157,'leic-t',2,leic-t0203).
turno(157,leti,3,leti0301).
evento(158,gestao,teorica,88,a4).
horario(158,segunda-feira,12.0,14.0,2.0,p2).
turno(158,'leic-t',2,leic-t0206).
turno(158,'leic-t',1,leic-t0107).
turno(158,'leic-t',1,leic-t0102).
turno(158,'leic-t',2,leic-t0203).
turno(158,leti,3,leti0301).
evento(159,gestao,pratica,40,'0-15').
horario(159,quarta-feira,12.0,13.5,1.5,p2).
turno(159,leti,1,leti0101).
turno(159,'leic-t',2,leic-t0204).
turno(159,'leic-t',1,leic-t0101).
turno(159,leti,3,leti0303).
evento(160,gestao,teorica,99,a4).
horario(160,segunda-feira,10.0,12.0,2.0,p2).
turno(160,'leic-t',1,leic-t0105).
turno(160,leti,1,leti0102).
turno(160,leti,1,leti0101).
turno(160,'leic-t',1,leic-t0101).
turno(160,'leic-t',2,leic-t0201).
turno(160,'leic-t',1,leic-t0106).
turno(160,leti,3,leti0303).
turno(160,leti,3,leti0302).
turno(160,leti,3,leti0301).
evento(161,gestao,pratica,35,'0-73').
horario(161,quinta-feira,12.5,14.0,1.5,p2).
turno(161,leti,1,leti0101).
turno(161,'leic-t',1,leic-t0101).
turno(161,'leic-t',2,leic-t0201).
turno(161,leti,3,leti0301).
evento(162,gestao,pratica,38,'0-16').
horario(162,quinta-feira,11.0,12.5,1.5,p2).
turno(162,'leic-t',1,leic-t0104).
turno(162,'leic-t',1,leic-t0103).
turno(162,'leic-t',2,leic-t0201).
turno(162,leti,3,leti0301).
evento(163,gestao,teorica,80,a3).
horario(163,segunda-feira,12.0,14.0,2.0,p2).
turno(163,'leic-t',1,leic-t0104).
turno(163,'leic-t',2,leic-t0202).
turno(163,leti,1,leti0103).
turno(163,'leic-t',2,leic-t0204).
turno(163,leti,3,leti0301).
evento(164,gestao,pratica,38,'0-16').
horario(164,terca-feira,12.5,14.0,1.5,p2).
turno(164,'leic-t',2,leic-t0202).
turno(164,leti,1,leti0101).
turno(164,'leic-t',1,leic-t0101).
turno(164,leti,3,leti0302).
evento(165,'sistemas eletronicos programaveis','teorico-pratica',6,'0-17').
horario(165,quarta-feira,8.0,10.0,2.0,p1).
turno(165,mee,1,mee0101).
evento(166,'sistemas eletronicos programaveis',laboratorial,6,'1-60').
horario(166,quarta-feira,10.0,11.5,1.5,p1).
turno(166,mee,1,mee0101).
evento(167,'sistemas embebidos',laboratorial,2,'1-60').
horario(167,quinta-feira,12.5,14.0,1.5,p2).
turno(167,mee,1,mee0101).
turno(167,meti,1,merc0101).
evento(168,'sistemas embebidos',laboratorial,11,'1-60').
horario(168,quinta-feira,11.0,12.5,1.5,p2).
turno(168,mee,1,mee0101).
turno(168,meti,1,merc0101).
evento(169,'sistemas embebidos',teorica,13,a4).
horario(169,sexta-feira,14.0,16.0,2.0,p2).
turno(169,mee,1,mee0101).
turno(169,meti,1,merc0101).
evento(170,'sistemas embebidos',teorica,13,'0-16').
horario(170,quinta-feira,9.0,11.0,2.0,p2).
turno(170,mee,1,mee0101).
turno(170,meti,1,merc0101).
evento(171,'introducao a economia',pratica,18,'0-19').
horario(171,quinta-feira,12.0,13.5,1.5,p1).
turno(171,lee,2,lee0201).
evento(172,'introducao a economia',teorica,37,'0-13').
horario(172,quarta-feira,10.5,12.5,2.0,p1).
turno(172,lee,2,lee0201).
evento(173,'introducao a economia',teorica,37,'1-24').
horario(173,quarta-feira,10.5,12.5,2.0,p1).
turno(173,lee,2,lee0201).
evento(174,aprendizagem,laboratorial,14,'0-75').
horario(174,quinta-feira,11.0,12.5,1.5,p1).
turno(174,'leic-t',3,leic-t0302).
evento(175,aprendizagem,laboratorial,14,'0-75').
horario(175,terca-feira,9.0,10.5,1.5,p1).
turno(175,'leic-t',3,leic-t0302).
evento(176,aprendizagem,teorica,86,a1).
horario(176,quinta-feira,9.0,11.0,2.0,p1).
turno(176,'leic-t',3,leic-t0302).
turno(176,'leic-t',3,leic-t0301).
turno(176,'leic-t',3,leic-t0304).
turno(176,'leic-t',3,leic-t0303).
evento(177,aprendizagem,teorica,86,a2).
horario(177,segunda-feira,10.5,12.5,2.0,p1).
turno(177,'leic-t',3,leic-t0302).
turno(177,'leic-t',3,leic-t0301).
turno(177,'leic-t',3,leic-t0304).
turno(177,'leic-t',3,leic-t0303).
evento(178,aprendizagem,laboratorial,17,'0-75').
horario(178,quarta-feira,9.0,10.5,1.5,p1).
turno(178,'leic-t',3,leic-t0301).
evento(179,aprendizagem,laboratorial,17,'1-15').
horario(179,segunda-feira,9.0,10.5,1.5,p1).
turno(179,'leic-t',3,leic-t0301).
evento(180,aprendizagem,laboratorial,23,'0-73').
horario(180,quarta-feira,9.0,10.5,1.5,p1).
turno(180,'leic-t',3,leic-t0303).
evento(181,aprendizagem,laboratorial,23,'1-11').
horario(181,segunda-feira,9.0,10.5,1.5,p1).
turno(181,'leic-t',3,leic-t0303).
evento(182,aprendizagem,laboratorial,33,'0-73').
horario(182,terca-feira,9.0,10.5,1.5,p1).
turno(182,'leic-t',3,leic-t0304).
evento(183,aprendizagem,laboratorial,33,'0-73').
horario(183,quinta-feira,11.0,12.5,1.5,p1).
turno(183,'leic-t',3,leic-t0304).
evento(184,'gestao de cadeias de abastecimento',pratica,37,'0-16').
horario(184,quinta-feira,17.0,18.5,1.5,p1).
turno(184,megi,1,megi0101).
turno(184,megi,1,megi0102).
turno(184,megi,1,megi0103).
evento(185,'gestao de cadeias de abastecimento',pratica,37,'1-4').
horario(185,segunda-feira,14.0,15.5,1.5,p1).
turno(185,megi,1,megi0101).
turno(185,megi,1,megi0102).
turno(185,megi,1,megi0103).
evento(186,'gestao de cadeias de abastecimento',teorica,101,a1).
horario(186,segunda-feira,15.5,17.5,2.0,p1).
turno(186,megi,1,megi0101).
turno(186,megi,1,megi0102).
turno(186,megi,1,megi0103).
evento(187,'gestao de cadeias de abastecimento',teorica,101,a2).
horario(187,quinta-feira,13.0,15.0,2.0,p1).
turno(187,megi,1,megi0101).
turno(187,megi,1,megi0102).
turno(187,megi,1,megi0103).
evento(188,'gestao de cadeias de abastecimento',pratica,24,'0-15').
horario(188,terca-feira,10.0,11.5,1.5,p1).
turno(188,megi,1,megi0101).
turno(188,megi,1,megi0102).
turno(188,megi,1,megi0103).
evento(189,'gestao de cadeias de abastecimento',pratica,24,'0-75').
horario(189,segunda-feira,11.0,12.5,1.5,p1).
turno(189,megi,1,megi0101).
turno(189,megi,1,megi0102).
turno(189,megi,1,megi0103).
evento(190,'gestao de cadeias de abastecimento',pratica,39,'0-15').
horario(190,quinta-feira,15.0,16.5,1.5,p1).
turno(190,megi,1,megi0101).
turno(190,megi,1,megi0102).
turno(190,megi,1,megi0103).
evento(191,'gestao de cadeias de abastecimento',pratica,39,semSala).
horario(191,segunda-feira,17.5,19.0,1.5,p1).
turno(191,megi,1,megi0101).
turno(191,megi,1,megi0102).
turno(191,megi,1,megi0103).
evento(192,'modelos de simulacao de sistemas','teorico-pratica',29,'0-9').
horario(192,terca-feira,16.0,18.0,2.0,p2).
turno(192,megi,1,megi0103).
evento(193,'modelos de simulacao de sistemas','teorico-pratica',29,a3).
horario(193,sexta-feira,12.5,14.5,2.0,p2).
turno(193,megi,1,megi0103).
evento(194,'modelos de simulacao de sistemas','teorico-pratica',29,'1-24').
horario(194,quinta-feira,16.5,18.5,2.0,p2).
turno(194,megi,1,megi0103).
evento(195,'modelos de simulacao de sistemas','teorico-pratica',30,'0-25').
horario(195,sexta-feira,14.5,16.5,2.0,p2).
turno(195,megi,1,megi0103).
evento(196,'modelos de simulacao de sistemas','teorico-pratica',30,'1-11').
horario(196,quinta-feira,14.5,16.5,2.0,indeterminado).
turno(196,megi,1,megi0103).
evento(197,'modelos de simulacao de sistemas','teorico-pratica',30,'1-11').
horario(197,quarta-feira,14.5,16.5,2.0,indeterminado).
turno(197,megi,1,megi0103).
evento(198,'modelos de simulacao de sistemas','teorico-pratica',30,'0-25').
horario(198,quinta-feira,14.5,16.5,2.0,p2).
turno(198,megi,1,megi0103).
evento(199,'modelos de simulacao de sistemas','teorico-pratica',30,'0-25').
horario(199,quarta-feira,14.5,16.5,2.0,p2).
turno(199,megi,1,megi0103).
evento(200,'modelos de simulacao de sistemas','teorico-pratica',22,'0-9').
horario(200,sexta-feira,17.0,19.0,2.0,p2).
turno(200,megi,1,megi0102).
evento(201,'modelos de simulacao de sistemas','teorico-pratica',22,'0-9').
horario(201,quarta-feira,16.5,18.5,2.0,p2).
turno(201,megi,1,megi0102).
evento(202,'modelos de simulacao de sistemas','teorico-pratica',22,'0-25').
horario(202,terca-feira,17.5,19.5,2.0,p2).
turno(202,megi,1,megi0102).
evento(203,'projeto em operacoes e logistica',laboratorial,3,'0-9').
horario(203,quinta-feira,14.0,15.5,1.5,p2).
turno(203,megi,2,megi0202).
turno(203,megi,2,megi0201).
evento(204,'projeto em operacoes e logistica',problemas,0,'0-9').
horario(204,quinta-feira,15.5,17.0,1.5,p2).
turno(204,megi,2,megi0202).
turno(204,megi,2,megi0201).
evento(205,'projeto em operacoes e logistica','teorico-pratica',68,'0-65').
horario(205,quarta-feira,16.0,17.5,1.5,p2).
turno(205,megi,2,megi0202).
turno(205,megi,2,megi0201).
evento(206,'projeto em operacoes e logistica','teorico-pratica',68,'0-65').
horario(206,quarta-feira,14.5,16.0,1.5,p2).
turno(206,megi,2,megi0202).
turno(206,megi,2,megi0201).
evento(207,'projeto em operacoes e logistica',laboratorial,20,'1-3').
horario(207,quarta-feira,17.5,19.0,1.5,p2).
turno(207,megi,2,megi0202).
turno(207,megi,2,megi0201).
evento(208,'propagacao e antenas',problemas,31,'0-17').
horario(208,segunda-feira,16.0,17.5,1.5,p1).
turno(208,leti,3,leti0303).
turno(208,leti,3,leti0302).
turno(208,leti,3,leti0301).
evento(209,'propagacao e antenas',problemas,31,'0-17').
horario(209,quarta-feira,10.5,12.0,1.5,p1).
turno(209,leti,3,leti0303).
turno(209,leti,3,leti0302).
turno(209,leti,3,leti0301).
evento(210,'propagacao e antenas',laboratorial,19,'1-64').
horario(210,segunda-feira,16.0,19.0,3.0,p1).
turno(210,leti,3,leti0303).
turno(210,leti,3,leti0302).
turno(210,leti,3,leti0301).
evento(211,'propagacao e antenas',teorica,68,a4).
horario(211,quarta-feira,12.5,14.5,2.0,p1).
turno(211,lee,3,lee0301).
turno(211,lee,3,lee0302).
turno(211,leti,3,leti0303).
turno(211,leti,3,leti0302).
turno(211,leti,3,leti0301).
evento(212,'propagacao e antenas',teorica,68,a4).
horario(212,sexta-feira,13.0,15.0,2.0,p1).
turno(212,lee,3,lee0301).
turno(212,lee,3,lee0302).
turno(212,leti,3,leti0303).
turno(212,leti,3,leti0302).
turno(212,leti,3,leti0301).
evento(213,'propagacao e antenas',laboratorial,16,'1-64').
horario(213,quarta-feira,9.0,12.0,3.0,p1).
turno(213,leti,3,leti0303).
turno(213,leti,3,leti0302).
turno(213,leti,3,leti0301).
evento(214,'propagacao e antenas',laboratorial,21,'1-64').
horario(214,quarta-feira,16.0,19.0,3.0,p1).
turno(214,lee,3,lee0301).
turno(214,lee,3,lee0302).
turno(214,leti,3,leti0303).
turno(214,leti,3,leti0302).
turno(214,leti,3,leti0301).
evento(215,'propagacao e antenas',problemas,37,'1-24').
horario(215,segunda-feira,18.0,19.5,1.5,p1).
turno(215,lee,3,lee0301).
turno(215,lee,3,lee0302).
turno(215,leti,3,leti0303).
turno(215,leti,3,leti0302).
turno(215,leti,3,leti0301).
evento(216,'propagacao e antenas',problemas,37,'1-24').
horario(216,quarta-feira,8.0,9.5,1.5,p1).
turno(216,lee,3,lee0301).
turno(216,lee,3,lee0302).
turno(216,leti,3,leti0303).
turno(216,leti,3,leti0302).
turno(216,leti,3,leti0301).
evento(217,'propagacao e antenas',laboratorial,9,'1-64').
horario(217,quinta-feira,14.0,17.0,3.0,p1).
turno(217,lee,3,lee0301).
turno(217,lee,3,lee0302).
turno(217,leti,3,leti0303).
turno(217,leti,3,leti0302).
turno(217,leti,3,leti0301).
evento(218,'ciber seguranca forense',teorica,50,'1-4').
horario(218,terca-feira,13.0,15.0,2.0,p1).
turno(218,meti,1,merc0101).
turno(218,'meic-t',1,meic-t0101).
evento(219,'ciber seguranca forense',teorica,50,'1-4').
horario(219,quarta-feira,10.5,12.5,2.0,p1).
turno(219,meti,1,merc0101).
turno(219,'meic-t',1,meic-t0101).
evento(220,'ciber seguranca forense',laboratorial,22,'0-14').
horario(220,quinta-feira,13.0,16.0,3.0,p1).
turno(220,meti,1,merc0101).
turno(220,'meic-t',1,meic-t0101).
evento(221,'ciber seguranca forense',laboratorial,27,'1-27').
horario(221,terca-feira,8.5,11.5,3.0,p1).
turno(221,meti,1,merc0101).
turno(221,'meic-t',1,meic-t0101).
evento(222,'ciber seguranca forense',laboratorial,24,'1-27').
horario(222,segunda-feira,14.0,17.0,3.0,p1).
turno(222,meti,1,merc0101).
turno(222,'meic-t',1,meic-t0101).
evento(223,'modelos de apoio a decisao',teorica,97,a3).
horario(223,quarta-feira,12.5,14.5,2.0,p2).
turno(223,megi,1,megi0101).
turno(223,megi,1,megi0102).
turno(223,megi,1,megi0103).
evento(224,'modelos de apoio a decisao',teorica,97,a5).
horario(224,quinta-feira,13.5,14.5,1.0,p2).
turno(224,megi,1,megi0101).
turno(224,megi,1,megi0102).
turno(224,megi,1,megi0103).
evento(225,'modelos de apoio a decisao',laboratorial,30,'0-9').
horario(225,terca-feira,11.0,13.0,2.0,p2).
turno(225,megi,1,megi0101).
evento(226,'modelos de apoio a decisao',laboratorial,21,'0-73').
horario(226,sexta-feira,9.5,11.5,2.0,p2).
turno(226,megi,1,megi0103).
evento(227,'modelos de apoio a decisao',pratica,36,'0-25').
horario(227,quinta-feira,16.5,17.5,1.0,p2).
turno(227,megi,1,megi0101).
evento(228,'modelos de apoio a decisao',pratica,36,'0-16').
horario(228,terca-feira,16.0,18.0,2.0,p2).
turno(228,megi,1,megi0101).
evento(229,'modelos de apoio a decisao',pratica,26,'0-15').
horario(229,quarta-feira,14.5,16.5,2.0,p2).
turno(229,megi,1,megi0102).
evento(230,'modelos de apoio a decisao',pratica,26,'0-16').
horario(230,sexta-feira,16.0,17.0,1.0,p2).
turno(230,megi,1,megi0102).
evento(231,'modelos de apoio a decisao',pratica,31,'1-3').
horario(231,quinta-feira,14.5,16.5,2.0,p2).
turno(231,megi,1,megi0103).
evento(232,'modelos de apoio a decisao',pratica,31,'1-2').
horario(232,sexta-feira,14.5,15.5,1.0,p2).
turno(232,megi,1,megi0103).
evento(233,'modelos de apoio a decisao',laboratorial,40,'0-23').
horario(233,quarta-feira,16.5,18.5,2.0,p2).
turno(233,megi,1,megi0102).
evento(234,'calculo diferencial e integral i','teorico-pratica',86,a1).
horario(234,segunda-feira,8.0,10.0,2.0,p1_2).
turno(234,legi,1,legi0104).
turno(234,legi,1,legi0101).
turno(234,legi,1,legi0105).
turno(234,legi,1,legi0102).
turno(234,legi,1,legi0103).
evento(235,'calculo diferencial e integral i','teorico-pratica',86,a4).
horario(235,terca-feira,12.0,14.0,2.0,p1_2).
turno(235,legi,1,legi0104).
turno(235,legi,1,legi0101).
turno(235,legi,1,legi0105).
turno(235,legi,1,legi0102).
turno(235,legi,1,legi0103).
evento(236,'calculo diferencial e integral i','teorico-pratica',54,a1).
horario(236,segunda-feira,10.0,12.0,2.0,p1_2).
turno(236,lee,1,lee0103).
turno(236,lee,1,lee0102).
turno(236,lee,1,lee0101).
evento(237,'calculo diferencial e integral i','teorico-pratica',54,a4).
horario(237,quinta-feira,8.0,10.0,2.0,p1_2).
turno(237,lee,1,lee0103).
turno(237,lee,1,lee0102).
turno(237,lee,1,lee0101).
evento(238,'ciencia de redes complexas',laboratorial,14,'0-14').
horario(238,sexta-feira,13.0,16.0,3.0,p1).
turno(238,meti,1,merc0101).
turno(238,'meic-t',1,meic-t0101).
evento(239,'analise e sintese de algoritmos',laboratorial,23,'0-17').
horario(239,segunda-feira,13.5,15.0,1.5,p2).
turno(239,'leic-t',2,leic-t0205).
turno(239,'leic-t',2,leic-t0201).
evento(240,'analise e sintese de algoritmos',laboratorial,23,'0-14').
horario(240,quarta-feira,10.5,12.0,1.5,p2).
turno(240,'leic-t',2,leic-t0205).
turno(240,'leic-t',2,leic-t0201).
evento(241,'analise e sintese de algoritmos',laboratorial,24,'0-17').
horario(241,terca-feira,10.5,12.0,1.5,p2).
turno(241,'leic-t',2,leic-t0206).
turno(241,'leic-t',2,leic-t0202).
evento(242,'analise e sintese de algoritmos',laboratorial,24,'0-75').
horario(242,quinta-feira,10.5,12.0,1.5,p2).
turno(242,'leic-t',2,leic-t0206).
turno(242,'leic-t',2,leic-t0202).
evento(243,'analise e sintese de algoritmos',teorica,117,a2).
horario(243,segunda-feira,15.0,17.0,2.0,p2).
turno(243,'leic-t',2,leic-t0206).
turno(243,'leic-t',2,leic-t0205).
turno(243,'leic-t',2,leic-t0202).
turno(243,'leic-t',2,leic-t0204).
turno(243,'leic-t',2,leic-t0201).
turno(243,'leic-t',2,leic-t0203).
evento(244,'analise e sintese de algoritmos',teorica,117,a5).
horario(244,terca-feira,15.0,17.0,2.0,p2).
turno(244,'leic-t',2,leic-t0206).
turno(244,'leic-t',2,leic-t0205).
turno(244,'leic-t',2,leic-t0202).
turno(244,'leic-t',2,leic-t0204).
turno(244,'leic-t',2,leic-t0201).
turno(244,'leic-t',2,leic-t0203).
evento(245,'analise e sintese de algoritmos',teorica,117,a5).
horario(245,sexta-feira,16.5,17.5,1.0,p2).
turno(245,'leic-t',2,leic-t0206).
turno(245,'leic-t',2,leic-t0205).
turno(245,'leic-t',2,leic-t0202).
turno(245,'leic-t',2,leic-t0204).
turno(245,'leic-t',2,leic-t0201).
turno(245,'leic-t',2,leic-t0203).
evento(246,'analise e sintese de algoritmos',laboratorial,25,'0-15').
horario(246,terca-feira,12.5,14.0,1.5,p2).
turno(246,'leic-t',2,leic-t0204).
evento(247,'analise e sintese de algoritmos',laboratorial,25,'0-17').
horario(247,quinta-feira,13.0,14.5,1.5,p2).
turno(247,'leic-t',2,leic-t0204).
evento(248,'analise e sintese de algoritmos',laboratorial,25,'0-17').
horario(248,quinta-feira,12.5,14.0,1.5,p2).
turno(248,'leic-t',2,leic-t0204).
evento(249,'analise e sintese de algoritmos',laboratorial,18,'0-73').
horario(249,segunda-feira,10.5,12.0,1.5,p2).
turno(249,'leic-t',2,leic-t0203).
evento(250,'analise e sintese de algoritmos',laboratorial,18,'0-15').
horario(250,sexta-feira,14.0,15.5,1.5,p2).
turno(250,'leic-t',2,leic-t0203).
evento(251,'analise e sintese de algoritmos',laboratorial,26,'0-23').
horario(251,sexta-feira,9.0,10.5,1.5,p2).
turno(251,'leic-t',2,leic-t0206).
turno(251,'leic-t',2,leic-t0205).
turno(251,'leic-t',2,leic-t0202).
turno(251,'leic-t',2,leic-t0204).
turno(251,'leic-t',2,leic-t0201).
turno(251,'leic-t',2,leic-t0203).
evento(252,'analise e sintese de algoritmos',laboratorial,26,'0-75').
horario(252,terca-feira,9.0,10.5,1.5,p2).
turno(252,'leic-t',2,leic-t0206).
turno(252,'leic-t',2,leic-t0205).
turno(252,'leic-t',2,leic-t0202).
turno(252,'leic-t',2,leic-t0204).
turno(252,'leic-t',2,leic-t0201).
turno(252,'leic-t',2,leic-t0203).
evento(253,'redes veiculares',teorica,9,'0-19').
horario(253,quinta-feira,14.0,16.0,2.0,p2).
turno(253,meti,1,merc0101).
evento(254,'redes veiculares',teorica,9,'0-19').
horario(254,segunda-feira,11.5,13.5,2.0,p2).
turno(254,meti,1,merc0101).
evento(255,'seguranca em software',laboratorial,28,'0-21').
horario(255,terca-feira,15.5,17.0,1.5,p2).
turno(255,'meic-t',1,meic-t0101).
evento(256,'seguranca em software',laboratorial,28,'0-21').
horario(256,segunda-feira,9.5,11.0,1.5,p2).
turno(256,'meic-t',1,meic-t0101).
evento(257,'seguranca em software',laboratorial,30,'0-21').
horario(257,terca-feira,12.0,13.5,1.5,p2).
turno(257,meti,1,merc0101).
turno(257,'meic-t',1,meic-t0101).
evento(258,'seguranca em software',laboratorial,30,'0-21').
horario(258,segunda-feira,13.5,15.0,1.5,p2).
turno(258,meti,1,merc0101).
turno(258,'meic-t',1,meic-t0101).
evento(259,'seguranca em software',teorica,54,a1).
horario(259,quinta-feira,11.5,13.0,1.5,indeterminado).
turno(259,meti,1,merc0101).
turno(259,'meic-t',1,meic-t0101).
evento(260,'seguranca em software',teorica,54,'1-24').
horario(260,terca-feira,10.0,12.0,2.0,p2).
turno(260,meti,1,merc0101).
turno(260,'meic-t',1,meic-t0101).
evento(261,'seguranca em software',teorica,54,a1).
horario(261,quinta-feira,11.5,13.5,2.0,p2).
turno(261,meti,1,merc0101).
turno(261,'meic-t',1,meic-t0101).
evento(262,'engenharia de sistema de larga escala',laboratorial,14,'1-27').
horario(262,quarta-feira,8.0,11.0,3.0,p1).
turno(262,meti,1,merc0101).
turno(262,'meic-t',1,meic-t0101).
evento(263,'engenharia de sistema de larga escala',teorica,16,'0-19').
horario(263,sexta-feira,9.5,11.5,2.0,p1).
turno(263,meti,1,merc0101).
turno(263,'meic-t',1,meic-t0101).
evento(264,'engenharia de sistema de larga escala',teorica,16,'0-19').
horario(264,terca-feira,8.0,10.0,2.0,p1).
turno(264,meti,1,merc0101).
turno(264,'meic-t',1,meic-t0101).
evento(265,'fundamentos de controlo',laboratorial,18,'1-64').
horario(265,segunda-feira,10.0,11.0,1.0,p2).
turno(265,lee,3,lee0301).
evento(266,'fundamentos de controlo',laboratorial,5,'1-64').
horario(266,segunda-feira,11.0,12.0,1.0,p2).
turno(266,lee,3,lee0302).
evento(267,'fundamentos de controlo','teorico-pratica',28,'1-11').
horario(267,quinta-feira,11.0,13.0,2.0,p2).
turno(267,lee,3,lee0301).
turno(267,lee,3,lee0302).
evento(268,'fundamentos de controlo','teorico-pratica',28,'1-11').
horario(268,sexta-feira,9.0,11.0,2.0,p2).
turno(268,lee,3,lee0301).
turno(268,lee,3,lee0302).
evento(269,'fundamentos de controlo','teorico-pratica',28,'1-11').
horario(269,segunda-feira,8.0,10.0,2.0,p2).
turno(269,lee,3,lee0301).
turno(269,lee,3,lee0302).
evento(270,'competencias comunicacionais em engenharia informatica e de computadores i',problemas,31,'0-49').
horario(270,terca-feira,10.0,11.5,1.5,p1).
turno(270,'meic-t',1,meic-t0101).
evento(271,'competencias comunicacionais em engenharia informatica e de computadores i',problemas,28,'0-49').
horario(271,segunda-feira,13.5,15.0,1.5,p1).
turno(271,'meic-t',1,meic-t0101).
evento(272,'competencias comunicacionais em engenharia informatica e de computadores i',problemas,41,'0-49').
horario(272,segunda-feira,17.0,18.5,1.5,p1).
turno(272,'meic-t',1,meic-t0101).
evento(273,'competencias comunicacionais em engenharia informatica e de computadores i',problemas,41,'0-49').
horario(273,segunda-feira,15.0,16.5,1.5,p1).
turno(273,'meic-t',1,meic-t0101).
evento(274,'engenharia e tecnologia de processos de negocio',seminario,37,'0-19').
horario(274,quarta-feira,14.0,17.0,3.0,p2).
turno(274,meti,1,merc0101).
turno(274,'meic-t',1,meic-t0101).
evento(275,'organizacao de computadores',laboratorial,23,'0-21').
horario(275,quarta-feira,9.0,10.5,1.5,p1).
turno(275,'leic-t',3,leic-t0304).
evento(276,'organizacao de computadores',laboratorial,23,'0-21').
horario(276,segunda-feira,9.0,10.5,1.5,p1).
turno(276,'leic-t',3,leic-t0304).
evento(277,'organizacao de computadores',teorica,85,a3).
horario(277,quarta-feira,8.0,9.0,1.0,p1).
turno(277,'leic-t',3,leic-t0302).
turno(277,'leic-t',3,leic-t0301).
turno(277,'leic-t',3,leic-t0304).
turno(277,'leic-t',3,leic-t0303).
evento(278,'organizacao de computadores',teorica,85,a4).
horario(278,segunda-feira,8.0,9.0,1.0,p1).
turno(278,'leic-t',3,leic-t0302).
turno(278,'leic-t',3,leic-t0301).
turno(278,'leic-t',3,leic-t0304).
turno(278,'leic-t',3,leic-t0303).
evento(279,'organizacao de computadores',teorica,85,a2).
horario(279,terca-feira,8.0,9.0,1.0,p1).
turno(279,'leic-t',3,leic-t0302).
turno(279,'leic-t',3,leic-t0301).
turno(279,'leic-t',3,leic-t0304).
turno(279,'leic-t',3,leic-t0303).
evento(280,'organizacao de computadores',teorica,85,a1).
horario(280,quinta-feira,8.0,9.0,1.0,p1).
turno(280,'leic-t',3,leic-t0302).
turno(280,'leic-t',3,leic-t0301).
turno(280,'leic-t',3,leic-t0304).
turno(280,'leic-t',3,leic-t0303).
evento(281,'organizacao de computadores',laboratorial,20,'0-21').
horario(281,terca-feira,9.0,10.5,1.5,p1).
turno(281,'leic-t',3,leic-t0303).
evento(282,'organizacao de computadores',laboratorial,20,'0-21').
horario(282,quinta-feira,11.0,12.5,1.5,p1).
turno(282,'leic-t',3,leic-t0303).
evento(283,'organizacao de computadores',laboratorial,21,'0-14').
horario(283,segunda-feira,9.0,10.5,1.5,p1).
turno(283,'leic-t',3,leic-t0302).
evento(284,'organizacao de computadores',laboratorial,21,'0-14').
horario(284,quarta-feira,9.0,10.5,1.5,p1).
turno(284,'leic-t',3,leic-t0302).
evento(285,'organizacao de computadores',laboratorial,23,'0-14').
horario(285,quinta-feira,11.0,12.5,1.5,p1).
turno(285,'leic-t',3,leic-t0301).
evento(286,'organizacao de computadores',laboratorial,23,'0-14').
horario(286,terca-feira,9.0,10.5,1.5,p1).
turno(286,'leic-t',3,leic-t0301).
evento(287,'engenharia economica','teorico-pratica',45,'1-24').
horario(287,segunda-feira,13.0,14.5,1.5,p1_2).
turno(287,megi,2,megi0202).
turno(287,megi,2,megi0201).
evento(288,'engenharia economica','teorico-pratica',45,'1-22').
horario(288,quinta-feira,17.5,19.0,1.5,p1_2).
turno(288,megi,2,megi0202).
turno(288,megi,2,megi0201).
evento(289,'desempenho e dimensionamento de redes e sistemas',teorica,25,'0-19').
horario(289,sexta-feira,11.5,13.5,2.0,p2).
turno(289,meti,1,merc0101).
turno(289,'meic-t',1,meic-t0101).
evento(290,'desempenho e dimensionamento de redes e sistemas',teorica,25,'0-19').
horario(290,terca-feira,15.5,17.5,2.0,p2).
turno(290,meti,1,merc0101).
turno(290,'meic-t',1,meic-t0101).
evento(291,'desempenho e dimensionamento de redes e sistemas',laboratorial,21,'0-21').
horario(291,terca-feira,17.5,19.0,1.5,p2).
turno(291,meti,1,merc0101).
turno(291,'meic-t',1,meic-t0101).
evento(292,'desempenho e dimensionamento de redes e sistemas',laboratorial,21,'1-19').
horario(292,sexta-feira,10.0,11.5,1.5,p2).
turno(292,meti,1,merc0101).
turno(292,'meic-t',1,meic-t0101).
evento(293,'calculo diferencial e integral i','teorico-pratica',65,a4).
horario(293,sexta-feira,10.0,12.0,2.0,p1_2).
turno(293,'leic-t',1,leic-t0107).
turno(293,'leic-t',1,leic-t0105).
turno(293,'leic-t',1,leic-t0103).
turno(293,'leic-t',1,leic-t0101).
evento(294,'calculo diferencial e integral i','teorico-pratica',65,a2).
horario(294,terca-feira,11.5,13.5,2.0,p1_2).
turno(294,'leic-t',1,leic-t0107).
turno(294,'leic-t',1,leic-t0105).
turno(294,'leic-t',1,leic-t0103).
turno(294,'leic-t',1,leic-t0101).
evento(295,'calculo diferencial e integral i','teorico-pratica',65,a2).
horario(295,segunda-feira,8.0,10.0,2.0,p1_2).
turno(295,'leic-t',1,leic-t0104).
turno(295,'leic-t',1,leic-t0102).
turno(295,'leic-t',1,leic-t0106).
evento(296,'calculo diferencial e integral i','teorico-pratica',65,a3).
horario(296,terca-feira,8.0,10.0,2.0,p1_2).
turno(296,'leic-t',1,leic-t0104).
turno(296,'leic-t',1,leic-t0102).
turno(296,'leic-t',1,leic-t0106).
evento(297,'introducao a engenharia eletronica',laboratorial,12,'1-64').
horario(297,quinta-feira,10.0,11.0,1.0,p1).
turno(297,lee,1,lee0102).
evento(298,'introducao a engenharia eletronica',laboratorial,12,'1-64').
horario(298,quinta-feira,11.0,12.0,1.0,p1).
turno(298,lee,1,lee0102).
evento(299,'introducao a engenharia eletronica',laboratorial,14,'1-64').
horario(299,sexta-feira,14.0,15.0,1.0,p1).
turno(299,lee,1,lee0103).
evento(300,'introducao a engenharia eletronica',teorica,39,a5).
horario(300,segunda-feira,9.0,10.0,1.0,p1).
turno(300,lee,1,lee0103).
turno(300,lee,1,lee0102).
turno(300,lee,1,lee0101).
evento(301,'introducao a engenharia eletronica',teorica,39,a5).
horario(301,segunda-feira,8.0,9.0,1.0,p1).
turno(301,lee,1,lee0103).
turno(301,lee,1,lee0102).
turno(301,lee,1,lee0101).
evento(302,'introducao a engenharia eletronica',teorica,39,'1-4').
horario(302,segunda-feira,9.0,10.0,1.0,p1).
turno(302,lee,1,lee0103).
turno(302,lee,1,lee0102).
turno(302,lee,1,lee0101).
evento(303,'introducao a engenharia eletronica',teorica,39,'1-4').
horario(303,segunda-feira,8.0,9.0,1.0,p1).
turno(303,lee,1,lee0103).
turno(303,lee,1,lee0102).
turno(303,lee,1,lee0101).
evento(304,'fisica  com laboratorio',teorica,33,a4).
horario(304,quarta-feira,14.5,16.5,2.0,p2).
turno(304,lee,2,lee0202).
turno(304,lee,2,lee0201).
evento(305,'fisica  com laboratorio',teorica,33,'1-2').
horario(305,segunda-feira,13.5,15.5,2.0,p2).
turno(305,lee,2,lee0202).
turno(305,lee,2,lee0201).
evento(306,'fisica  com laboratorio',laboratorial,0,'1-12').
horario(306,quinta-feira,11.0,13.0,2.0,p2).
turno(306,lee,2,lee0201).
evento(307,'fisica  com laboratorio',laboratorial,0,'1-14').
horario(307,sexta-feira,10.0,12.0,2.0,p2).
turno(307,lee,2,lee0202).
evento(308,'fisica  com laboratorio','teorico-pratica',3,'0-17').
horario(308,segunda-feira,17.5,18.5,1.0,p2).
turno(308,lee,2,lee0202).
evento(309,'fisica  com laboratorio','teorico-pratica',30,'0-15').
horario(309,segunda-feira,15.5,16.5,1.0,p2).
turno(309,lee,2,lee0201).
evento(310,'sistemas de comunicacoes',laboratorial,13,'1-28').
horario(310,quarta-feira,9.5,11.5,2.0,p1).
turno(310,lee,3,lee0301).
turno(310,lee,3,lee0302).
evento(311,'sistemas de comunicacoes',laboratorial,10,semSala).
horario(311,quarta-feira,14.5,16.5,2.0,p1).
turno(311,leti,3,leti0303).
turno(311,leti,3,leti0301).
evento(312,'sistemas de comunicacoes',teorica,90,semSala).
horario(312,sexta-feira,15.0,17.0,2.0,p1).
turno(312,lee,3,lee0301).
turno(312,lee,3,lee0302).
turno(312,leti,3,leti0303).
turno(312,leti,3,leti0302).
turno(312,leti,3,leti0301).
evento(313,'sistemas de comunicacoes',teorica,90,a4).
horario(313,segunda-feira,9.0,11.0,2.0,p1).
turno(313,lee,3,lee0301).
turno(313,lee,3,lee0302).
turno(313,leti,3,leti0303).
turno(313,leti,3,leti0302).
turno(313,leti,3,leti0301).
evento(314,'sistemas de comunicacoes',problemas,35,'0-23').
horario(314,sexta-feira,9.0,11.0,2.0,p1).
turno(314,leti,3,leti0303).
turno(314,leti,3,leti0302).
turno(314,leti,3,leti0301).
evento(315,'sistemas de comunicacoes',problemas,35,'1-24').
horario(315,segunda-feira,12.0,13.0,1.0,p1).
turno(315,leti,3,leti0303).
turno(315,leti,3,leti0302).
turno(315,leti,3,leti0301).
evento(316,'sistemas de comunicacoes',problemas,24,'0-73').
horario(316,segunda-feira,11.0,12.0,1.0,p1).
turno(316,lee,3,lee0301).
turno(316,lee,3,lee0302).
evento(317,'sistemas de comunicacoes',problemas,24,'0-15').
horario(317,quarta-feira,9.5,11.5,2.0,p1).
turno(317,lee,3,lee0301).
turno(317,lee,3,lee0302).
evento(318,'sistemas de comunicacoes',laboratorial,15,'1-28').
horario(318,segunda-feira,14.0,16.0,2.0,p1).
turno(318,leti,3,leti0303).
turno(318,leti,3,leti0302).
turno(318,leti,3,leti0301).
evento(319,'sistemas de comunicacoes',laboratorial,16,'1-28').
horario(319,segunda-feira,16.0,18.0,2.0,p1).
turno(319,lee,3,lee0301).
turno(319,lee,3,lee0302).
turno(319,leti,3,leti0303).
turno(319,leti,3,leti0301).
evento(320,'sistemas de comunicacoes',problemas,32,'0-23').
horario(320,segunda-feira,14.0,16.0,2.0,p1).
turno(320,lee,3,lee0301).
turno(320,lee,3,lee0302).
turno(320,leti,3,leti0303).
turno(320,leti,3,leti0302).
turno(320,leti,3,leti0301).
evento(321,'fisica  com laboratorio','teorico-pratica',3,'0-9').
horario(321,quarta-feira,13.5,14.5,1.0,p1).
turno(321,lee,2,lee0202).
evento(322,'fisica  com laboratorio','teorico-pratica',28,'0-17').
horario(322,quarta-feira,12.5,13.5,1.0,p1).
turno(322,lee,2,lee0201).
evento(323,'fisica  com laboratorio',laboratorial,0,'1-14').
horario(323,segunda-feira,15.5,17.5,2.0,p1).
turno(323,lee,2,lee0201).
evento(324,'fisica  com laboratorio',laboratorial,0,'1-14').
horario(324,terca-feira,11.0,13.0,2.0,p1).
turno(324,lee,2,lee0202).
evento(325,'fisica  com laboratorio',teorica,31,a4).
horario(325,terca-feira,14.5,16.5,2.0,p1).
turno(325,lee,2,lee0202).
turno(325,lee,2,lee0201).
evento(326,'fisica  com laboratorio',teorica,31,a4).
horario(326,segunda-feira,13.5,15.5,2.0,p1).
turno(326,lee,2,lee0202).
turno(326,lee,2,lee0201).
evento(327,'regulacao do medicamento e dispositivos medicos',seminario,0,'0-13').
horario(327,terca-feira,11.5,12.5,1.0,p2).
turno(327,mbmrp,1,mbmrp0103).
turno(327,mbmrp,1,mbmrp0102).
turno(327,mbmrp,1,mbmrp0101).
evento(328,'regulacao do medicamento e dispositivos medicos',seminario,2,'0-13').
horario(328,terca-feira,10.0,13.0,3.0,p2).
turno(328,mbmrp,1,mbmrp0103).
turno(328,mbmrp,1,mbmrp0102).
turno(328,mbmrp,1,mbmrp0101).
evento(329,'regulacao do medicamento e dispositivos medicos',teorica,15,'0-13').
horario(329,segunda-feira,11.0,12.0,1.0,p2).
turno(329,mbmrp,1,mbmrp0103).
turno(329,mbmrp,1,mbmrp0102).
turno(329,mbmrp,1,mbmrp0101).
evento(330,'regulacao do medicamento e dispositivos medicos',pratica,19,'0-19').
horario(330,quinta-feira,11.0,12.0,1.0,p2).
turno(330,mbmrp,1,mbmrp0103).
turno(330,mbmrp,1,mbmrp0102).
turno(330,mbmrp,1,mbmrp0101).
evento(331,'computacao grafica para jogos',laboratorial,13,'1-29').
horario(331,sexta-feira,14.0,15.5,1.5,p2).
turno(331,'meic-t',1,meic-t0101).
evento(332,'computacao grafica para jogos',laboratorial,13,'1-29').
horario(332,sexta-feira,11.5,13.0,1.5,p2).
turno(332,'meic-t',1,meic-t0101).
evento(333,'computacao grafica para jogos',teorica,40,'1-3').
horario(333,sexta-feira,9.5,11.5,2.0,p2).
turno(333,'meic-t',1,meic-t0101).
evento(334,'computacao grafica para jogos',teorica,40,'0-16').
horario(334,terca-feira,8.5,10.5,2.0,p2).
turno(334,'meic-t',1,meic-t0101).
evento(335,'computacao grafica para jogos',laboratorial,22,'1-29').
horario(335,terca-feira,12.0,13.5,1.5,p2).
turno(335,'meic-t',1,meic-t0101).
evento(336,'computacao grafica para jogos',laboratorial,22,'1-29').
horario(336,terca-feira,10.5,12.0,1.5,p2).
turno(336,'meic-t',1,meic-t0101).
evento(337,'design de jogos',teorica,41,'1-3').
horario(337,segunda-feira,11.0,13.0,2.0,p1).
turno(337,'meic-t',1,meic-t0101).
evento(338,'design de jogos',teorica,41,'1-3').
horario(338,segunda-feira,9.0,11.0,2.0,p1).
turno(338,'meic-t',1,meic-t0101).
evento(339,'design de jogos',laboratorial,15,'1-32').
horario(339,terca-feira,9.5,12.5,3.0,p1).
turno(339,'meic-t',1,meic-t0101).
evento(340,'design de jogos',laboratorial,7,'1-32').
horario(340,terca-feira,15.5,18.5,3.0,p1).
turno(340,'meic-t',1,meic-t0101).
evento(341,'design de jogos',laboratorial,20,'1-32').
horario(341,segunda-feira,14.0,17.0,3.0,p1).
turno(341,'meic-t',1,meic-t0101).
evento(342,'competencias transversais mee i',seminario,13,semSala).
horario(342,sexta-feira,10.0,12.0,2.0,p1).
turno(342,mee,1,mee0101).
evento(343,'algebra linear','teorico-pratica',68,semSala).
horario(343,quinta-feira,8.0,10.0,2.0,p1_2).
turno(343,leti,1,leti0103).
turno(343,leti,1,leti0102).
turno(343,leti,1,leti0101).
evento(344,'algebra linear','teorico-pratica',68,a1).
horario(344,terca-feira,11.5,13.5,2.0,p1_2).
turno(344,leti,1,leti0103).
turno(344,leti,1,leti0102).
turno(344,leti,1,leti0101).
evento(345,'computacao e programacao',laboratorial,30,'0-9').
horario(345,quinta-feira,11.0,13.0,2.0,p2).
turno(345,legi,1,legi0105).
turno(345,legi,1,legi0102).
evento(346,'computacao e programacao',laboratorial,30,'0-73').
horario(346,terca-feira,10.0,12.0,2.0,p2).
turno(346,legi,1,legi0105).
turno(346,legi,1,legi0102).
evento(347,'computacao e programacao',teorica,91,a3).
horario(347,quinta-feira,9.0,11.0,2.0,p2).
turno(347,legi,1,legi0104).
turno(347,legi,1,legi0101).
turno(347,legi,1,legi0105).
turno(347,legi,1,legi0102).
turno(347,legi,1,legi0103).
evento(348,'computacao e programacao',teorica,91,a2).
horario(348,segunda-feira,10.0,12.0,2.0,p2).
turno(348,legi,1,legi0104).
turno(348,legi,1,legi0101).
turno(348,legi,1,legi0105).
turno(348,legi,1,legi0102).
turno(348,legi,1,legi0103).
evento(349,'computacao e programacao',laboratorial,26,'1-15').
horario(349,quarta-feira,9.5,11.5,2.0,p2).
turno(349,legi,1,legi0103).
evento(350,'computacao e programacao',laboratorial,26,'1-15').
horario(350,sexta-feira,8.0,10.0,2.0,p2).
turno(350,legi,1,legi0103).
evento(351,'computacao e programacao',laboratorial,32,a1).
horario(351,sexta-feira,10.0,12.0,2.0,p2).
turno(351,legi,1,legi0104).
turno(351,legi,1,legi0101).
evento(352,'computacao e programacao',laboratorial,32,'1-4').
horario(352,quarta-feira,11.5,13.5,2.0,p2).
turno(352,legi,1,legi0104).
turno(352,legi,1,legi0101).
evento(353,'probabilidade e estatistica','teorico-pratica',93,a4).
horario(353,quarta-feira,17.5,19.5,2.0,p1_2).
turno(353,legi,2,legi0205).
turno(353,legi,2,legi0202).
turno(353,legi,2,legi0204).
turno(353,legi,2,legi0201).
turno(353,legi,2,legi0203).
evento(354,'probabilidade e estatistica','teorico-pratica',93,a5).
horario(354,quinta-feira,15.5,17.5,2.0,p1_2).
turno(354,legi,2,legi0205).
turno(354,legi,2,legi0202).
turno(354,legi,2,legi0204).
turno(354,legi,2,legi0201).
turno(354,legi,2,legi0203).
evento(355,'introducao a economia',pratica,20,'0-13').
horario(355,terca-feira,14.5,16.0,1.5,p2).
turno(355,leti,1,leti0102).
turno(355,leti,1,leti0101).
evento(356,'introducao a economia',teorica,37,'0-13').
horario(356,sexta-feira,10.5,12.5,2.0,p2).
turno(356,leti,1,leti0102).
turno(356,leti,1,leti0101).
evento(357,'controlo de gestao','teorico-pratica',28,'1-3').
horario(357,sexta-feira,15.0,17.0,2.0,p1).
turno(357,megi,2,megi0202).
turno(357,megi,2,megi0201).
evento(358,'controlo de gestao','teorico-pratica',28,'1-2').
horario(358,terca-feira,15.5,17.5,2.0,p1).
turno(358,megi,2,megi0202).
turno(358,megi,2,megi0201).
evento(359,'controlo de gestao','teorico-pratica',28,'1-4').
horario(359,quinta-feira,15.5,17.5,2.0,p1).
turno(359,megi,2,megi0202).
turno(359,megi,2,megi0201).
evento(360,'sistemas de posicionamento e telecomunicacoes por satelite','teorico-pratica',5,'0-17').
horario(360,sexta-feira,15.5,16.5,1.0,p1).
turno(360,meti,1,merc0101).
evento(361,'sistemas de posicionamento e telecomunicacoes por satelite','teorico-pratica',5,'0-17').
horario(361,sexta-feira,13.5,15.5,2.0,p1).
turno(361,meti,1,merc0101).
evento(362,'sistemas de posicionamento e telecomunicacoes por satelite','teorico-pratica',5,'1-22').
horario(362,segunda-feira,10.0,12.0,2.0,p1).
turno(362,meti,1,merc0101).
evento(363,'sistemas de posicionamento e telecomunicacoes por satelite','teorico-pratica',5,'0-17').
horario(363,quinta-feira,8.0,10.0,2.0,p1).
turno(363,meti,1,merc0101).
evento(364,'programacao com objectos',laboratorial,18,'1-11').
horario(364,segunda-feira,12.5,14.0,1.5,p1).
turno(364,leti,2,leti0201).
evento(365,'programacao com objectos',laboratorial,10,'1-22').
horario(365,sexta-feira,13.0,14.5,1.5,p1).
turno(365,leti,2,leti0204).
evento(366,'programacao com objectos',laboratorial,10,'1-3').
horario(366,terca-feira,13.0,14.5,1.5,p1).
turno(366,leti,2,leti0204).
evento(367,'programacao com objectos',laboratorial,12,'0-17').
horario(367,segunda-feira,12.5,14.0,1.5,p1).
turno(367,leti,2,leti0203).
evento(368,'programacao com objectos',laboratorial,12,'1-2').
horario(368,quinta-feira,15.0,16.5,1.5,p1).
turno(368,leti,2,leti0203).
evento(369,'programacao com objectos',laboratorial,15,'0-9').
horario(369,sexta-feira,13.0,14.5,1.5,p1).
turno(369,leti,2,leti0202).
evento(370,'programacao com objectos',laboratorial,15,'1-22').
horario(370,terca-feira,13.0,14.5,1.5,p1).
turno(370,leti,2,leti0202).
evento(371,'programacao com objectos',laboratorial,18,'0-14').
horario(371,segunda-feira,15.5,17.0,1.5,p1).
turno(371,'leic-t',2,leic-t0206).
evento(372,'programacao com objectos',laboratorial,18,'0-27').
horario(372,quinta-feira,13.0,14.5,1.5,p1).
turno(372,'leic-t',2,leic-t0206).
evento(373,'programacao com objectos',laboratorial,15,'0-14').
horario(373,quarta-feira,13.5,15.0,1.5,p1).
turno(373,'leic-t',2,leic-t0202).
evento(374,'programacao com objectos',laboratorial,15,'1-17').
horario(374,segunda-feira,15.5,17.0,1.5,p1).
turno(374,'leic-t',2,leic-t0202).
evento(375,'programacao com objectos',teorica,102,a3).
horario(375,quarta-feira,17.5,18.5,1.0,p1).
turno(375,'leic-t',2,leic-t0206).
turno(375,'leic-t',2,leic-t0205).
turno(375,'leic-t',2,leic-t0202).
turno(375,'leic-t',2,leic-t0204).
turno(375,'leic-t',2,leic-t0201).
turno(375,'leic-t',2,leic-t0203).
evento(376,'programacao com objectos',teorica,102,a5).
horario(376,quinta-feira,14.5,15.5,1.0,p1).
turno(376,'leic-t',2,leic-t0206).
turno(376,'leic-t',2,leic-t0205).
turno(376,'leic-t',2,leic-t0202).
turno(376,'leic-t',2,leic-t0204).
turno(376,'leic-t',2,leic-t0201).
turno(376,'leic-t',2,leic-t0203).
evento(377,'programacao com objectos',teorica,102,a3).
horario(377,segunda-feira,13.0,14.0,1.0,p1).
turno(377,'leic-t',2,leic-t0206).
turno(377,'leic-t',2,leic-t0205).
turno(377,'leic-t',2,leic-t0202).
turno(377,'leic-t',2,leic-t0204).
turno(377,'leic-t',2,leic-t0201).
turno(377,'leic-t',2,leic-t0203).
evento(378,'programacao com objectos',teorica,102,a3).
horario(378,sexta-feira,15.5,16.5,1.0,p1).
turno(378,'leic-t',2,leic-t0206).
turno(378,'leic-t',2,leic-t0205).
turno(378,'leic-t',2,leic-t0202).
turno(378,'leic-t',2,leic-t0204).
turno(378,'leic-t',2,leic-t0201).
turno(378,'leic-t',2,leic-t0203).
evento(379,'programacao com objectos',teorica,102,a3).
horario(379,terca-feira,15.5,16.5,1.0,p1).
turno(379,'leic-t',2,leic-t0206).
turno(379,'leic-t',2,leic-t0205).
turno(379,'leic-t',2,leic-t0202).
turno(379,'leic-t',2,leic-t0204).
turno(379,'leic-t',2,leic-t0201).
turno(379,'leic-t',2,leic-t0203).
evento(380,'programacao com objectos',teorica,51,a3).
horario(380,sexta-feira,16.5,17.5,1.0,p1).
turno(380,leti,2,leti0201).
turno(380,leti,2,leti0203).
turno(380,leti,2,leti0202).
turno(380,leti,2,leti0204).
evento(381,'programacao com objectos',teorica,51,a3).
horario(381,terca-feira,14.5,15.5,1.0,p1).
turno(381,leti,2,leti0201).
turno(381,leti,2,leti0203).
turno(381,leti,2,leti0202).
turno(381,leti,2,leti0204).
evento(382,'programacao com objectos',teorica,51,a3).
horario(382,segunda-feira,14.0,15.0,1.0,p1).
turno(382,leti,2,leti0201).
turno(382,leti,2,leti0203).
turno(382,leti,2,leti0202).
turno(382,leti,2,leti0204).
evento(383,'programacao com objectos',teorica,51,a3).
horario(383,quarta-feira,13.5,14.5,1.0,p1).
turno(383,leti,2,leti0201).
turno(383,leti,2,leti0203).
turno(383,leti,2,leti0202).
turno(383,leti,2,leti0204).
evento(384,'programacao com objectos',teorica,51,a3).
horario(384,quinta-feira,11.0,12.0,1.0,p1).
turno(384,leti,2,leti0201).
turno(384,leti,2,leti0203).
turno(384,leti,2,leti0202).
turno(384,leti,2,leti0204).
evento(385,'programacao com objectos',laboratorial,15,'0-21').
horario(385,segunda-feira,14.0,15.5,1.5,p1).
turno(385,'leic-t',2,leic-t0204).
evento(386,'programacao com objectos',laboratorial,15,'1-19').
horario(386,quarta-feira,13.5,15.0,1.5,p1).
turno(386,'leic-t',2,leic-t0204).
evento(387,'programacao com objectos',laboratorial,18,'1-17').
horario(387,segunda-feira,10.5,12.0,1.5,p1).
turno(387,'leic-t',2,leic-t0205).
evento(388,'programacao com objectos',laboratorial,18,'1-15').
horario(388,quinta-feira,13.0,14.5,1.5,p1).
turno(388,'leic-t',2,leic-t0205).
evento(389,'programacao com objectos',laboratorial,17,'0-21').
horario(389,segunda-feira,10.5,12.0,1.5,p1).
turno(389,'leic-t',2,leic-t0203).
evento(390,'programacao com objectos',laboratorial,17,'1-17').
horario(390,quarta-feira,10.5,12.0,1.5,p1).
turno(390,'leic-t',2,leic-t0203).
evento(391,'programacao com objectos',laboratorial,15,'1-15').
horario(391,quarta-feira,10.5,12.0,1.5,p1).
turno(391,'leic-t',2,leic-t0201).
evento(392,'programacao com objectos',laboratorial,15,'0-14').
horario(392,segunda-feira,14.0,15.5,1.5,p1).
turno(392,'leic-t',2,leic-t0201).
evento(393,gestao,pratica,41,'1-3').
horario(393,quarta-feira,11.0,12.5,1.5,p1).
turno(393,lee,2,lee0202).
turno(393,lee,2,lee0201).
evento(394,gestao,teorica,41,'1-4').
horario(394,quinta-feira,13.0,15.0,2.0,p1).
turno(394,lee,2,lee0202).
turno(394,lee,2,lee0201).
evento(395,'quimica geral',laboratorial,22,'1-75').
horario(395,quinta-feira,10.0,12.0,2.0,p1).
turno(395,lee,1,lee0103).
turno(395,lee,1,lee0101).
evento(396,'quimica geral',laboratorial,19,'1-75').
horario(396,quarta-feira,9.5,11.5,2.0,p1).
turno(396,legi,1,legi0102).
turno(396,legi,1,legi0103).
evento(397,'quimica geral',problemas,37,'0-17').
horario(397,quinta-feira,13.5,15.5,2.0,p1).
turno(397,lee,1,lee0103).
turno(397,lee,1,lee0102).
turno(397,lee,1,lee0101).
evento(398,'quimica geral',laboratorial,19,'1-75').
horario(398,quarta-feira,14.5,16.5,2.0,p1).
turno(398,legi,1,legi0104).
turno(398,legi,1,legi0103).
evento(399,'quimica geral',laboratorial,18,'1-75').
horario(399,sexta-feira,10.0,12.0,2.0,p1).
turno(399,legi,1,legi0101).
evento(400,'quimica geral',teorica,81,a3).
horario(400,sexta-feira,12.0,13.0,1.0,p1).
turno(400,legi,1,legi0104).
turno(400,legi,1,legi0101).
turno(400,legi,1,legi0105).
turno(400,legi,1,legi0102).
turno(400,legi,1,legi0103).
turno(400,lee,1,lee0103).
turno(400,lee,1,lee0102).
turno(400,lee,1,lee0101).
evento(401,'quimica geral',problemas,29,'0-9').
horario(401,terca-feira,15.0,17.0,2.0,p1).
turno(401,legi,1,legi0104).
turno(401,legi,1,legi0102).
evento(402,'quimica geral',teorica,112,a2).
horario(402,quarta-feira,11.5,13.5,2.0,p1).
turno(402,legi,1,legi0104).
turno(402,legi,1,legi0101).
turno(402,legi,1,legi0105).
turno(402,legi,1,legi0102).
turno(402,legi,1,legi0103).
turno(402,lee,1,lee0103).
turno(402,lee,1,lee0102).
turno(402,lee,1,lee0101).
evento(403,'quimica geral',teorica,112,a1).
horario(403,terca-feira,8.0,10.0,2.0,p1).
turno(403,legi,1,legi0104).
turno(403,legi,1,legi0101).
turno(403,legi,1,legi0105).
turno(403,legi,1,legi0102).
turno(403,legi,1,legi0103).
turno(403,lee,1,lee0103).
turno(403,lee,1,lee0102).
turno(403,lee,1,lee0101).
evento(404,'quimica geral',laboratorial,20,'1-75').
horario(404,segunda-feira,10.0,12.0,2.0,p1).
turno(404,legi,1,legi0105).
turno(404,legi,1,legi0102).
evento(405,'quimica geral',problemas,40,'0-25').
horario(405,terca-feira,10.0,12.0,2.0,p1).
turno(405,legi,1,legi0101).
turno(405,legi,1,legi0105).
turno(405,legi,1,legi0103).
evento(406,'quimica geral',laboratorial,17,'1-75').
horario(406,sexta-feira,8.0,10.0,2.0,p1).
turno(406,lee,1,lee0102).
evento(407,'avaliacao de projetos',teorica,107,a2).
horario(407,quarta-feira,14.0,15.0,1.0,p2).
turno(407,legi,2,legi0205).
turno(407,legi,2,legi0202).
turno(407,legi,2,legi0204).
turno(407,legi,2,legi0201).
turno(407,legi,2,legi0203).
evento(408,'avaliacao de projetos',teorica,107,a3).
horario(408,terca-feira,14.5,16.5,2.0,p2).
turno(408,legi,2,legi0205).
turno(408,legi,2,legi0202).
turno(408,legi,2,legi0204).
turno(408,legi,2,legi0201).
turno(408,legi,2,legi0203).
evento(409,'avaliacao de projetos',pratica,35,'0-17').
horario(409,terca-feira,13.5,14.5,1.0,p2).
turno(409,legi,2,legi0205).
turno(409,legi,2,legi0202).
evento(410,'avaliacao de projetos',pratica,30,'1-3').
horario(410,terca-feira,10.0,11.0,1.0,p2).
turno(410,legi,2,legi0203).
evento(411,'avaliacao de projetos',pratica,35,'0-17').
horario(411,terca-feira,16.5,17.5,1.0,p2).
turno(411,legi,2,legi0204).
turno(411,legi,2,legi0201).
evento(412,'competencias comunicacionais em engenharia de telecomunicacoes e informatica i',problemas,36,'0-49').
horario(412,quarta-feira,14.5,16.0,1.5,p1).
turno(412,meti,1,merc0101).
evento(413,'competencias comunicacionais em engenharia de telecomunicacoes e informatica i',problemas,36,'0-49').
horario(413,terca-feira,11.5,13.0,1.5,p1).
turno(413,meti,1,merc0101).
evento(414,'logica para programacao',laboratorial,27,'0-16').
horario(414,segunda-feira,12.0,13.5,1.5,p2).
turno(414,'leic-t',1,leic-t0105).
turno(414,'leic-t',1,leic-t0106).
evento(415,'logica para programacao',laboratorial,27,'0-15').
horario(415,quinta-feira,11.0,12.5,1.5,p2).
turno(415,'leic-t',1,leic-t0105).
turno(415,'leic-t',1,leic-t0106).
evento(416,'logica para programacao',laboratorial,27,'0-15').
horario(416,terca-feira,14.0,15.5,1.5,p2).
turno(416,'leic-t',1,leic-t0101).
evento(417,'logica para programacao',laboratorial,27,'0-25').
horario(417,quinta-feira,13.0,14.5,1.5,p2).
turno(417,'leic-t',1,leic-t0101).
evento(418,'logica para programacao',laboratorial,26,'0-73').
horario(418,quinta-feira,11.0,12.5,1.5,indeterminado).
turno(418,'leic-t',1,leic-t0102).
evento(419,'logica para programacao',laboratorial,26,'0-15').
horario(419,segunda-feira,10.0,11.5,1.5,p2).
turno(419,'leic-t',1,leic-t0102).
evento(420,'logica para programacao',laboratorial,26,'0-25').
horario(420,quinta-feira,11.0,12.5,1.5,p2).
turno(420,'leic-t',1,leic-t0102).
evento(421,'logica para programacao',teorica,149,a1).
horario(421,terca-feira,10.0,11.0,1.0,p2).
turno(421,'leic-t',1,leic-t0107).
turno(421,'leic-t',1,leic-t0105).
turno(421,'leic-t',1,leic-t0104).
turno(421,'leic-t',1,leic-t0103).
turno(421,'leic-t',1,leic-t0101).
turno(421,'leic-t',1,leic-t0102).
turno(421,'leic-t',1,leic-t0106).
evento(422,'logica para programacao',teorica,149,a1).
horario(422,sexta-feira,8.0,10.0,2.0,p2).
turno(422,'leic-t',1,leic-t0107).
turno(422,'leic-t',1,leic-t0105).
turno(422,'leic-t',1,leic-t0104).
turno(422,'leic-t',1,leic-t0103).
turno(422,'leic-t',1,leic-t0101).
turno(422,'leic-t',1,leic-t0102).
turno(422,'leic-t',1,leic-t0106).
evento(423,'logica para programacao',teorica,149,a1).
horario(423,quinta-feira,9.0,11.0,2.0,p2).
turno(423,'leic-t',1,leic-t0107).
turno(423,'leic-t',1,leic-t0105).
turno(423,'leic-t',1,leic-t0104).
turno(423,'leic-t',1,leic-t0103).
turno(423,'leic-t',1,leic-t0101).
turno(423,'leic-t',1,leic-t0102).
turno(423,'leic-t',1,leic-t0106).
evento(424,'logica para programacao',laboratorial,22,'0-15').
horario(424,sexta-feira,10.0,11.5,1.5,p2).
turno(424,'leic-t',1,leic-t0107).
turno(424,'leic-t',1,leic-t0105).
turno(424,'leic-t',1,leic-t0104).
turno(424,'leic-t',1,leic-t0103).
turno(424,'leic-t',1,leic-t0101).
turno(424,'leic-t',1,leic-t0102).
turno(424,'leic-t',1,leic-t0106).
evento(425,'logica para programacao',laboratorial,22,'0-25').
horario(425,terca-feira,8.5,10.0,1.5,p2).
turno(425,'leic-t',1,leic-t0107).
turno(425,'leic-t',1,leic-t0105).
turno(425,'leic-t',1,leic-t0104).
turno(425,'leic-t',1,leic-t0103).
turno(425,'leic-t',1,leic-t0101).
turno(425,'leic-t',1,leic-t0102).
turno(425,'leic-t',1,leic-t0106).
evento(426,'logica para programacao',laboratorial,24,'0-25').
horario(426,sexta-feira,12.0,13.5,1.5,p2).
turno(426,'leic-t',1,leic-t0107).
turno(426,'leic-t',1,leic-t0104).
evento(427,'logica para programacao',laboratorial,24,'0-16').
horario(427,segunda-feira,10.0,11.5,1.5,p2).
turno(427,'leic-t',1,leic-t0107).
turno(427,'leic-t',1,leic-t0104).
evento(428,'logica para programacao',laboratorial,26,'0-23').
horario(428,quinta-feira,13.0,14.5,1.5,p2).
turno(428,'leic-t',1,leic-t0103).
evento(429,'logica para programacao',laboratorial,26,'0-9').
horario(429,segunda-feira,12.0,13.5,1.5,p2).
turno(429,'leic-t',1,leic-t0103).
evento(430,'introducao a matematica computacional','teorico-pratica',38,'0-23').
horario(430,quinta-feira,15.0,17.0,2.0,p1).
turno(430,lee,2,lee0202).
turno(430,lee,2,lee0201).
evento(431,'introducao a matematica computacional','teorico-pratica',38,'0-23').
horario(431,terca-feira,16.5,18.5,2.0,p1).
turno(431,lee,2,lee0202).
turno(431,lee,2,lee0201).
evento(432,'sistemas operativos',laboratorial,20,'1-15').
horario(432,quinta-feira,13.0,14.5,1.5,p2).
turno(432,'leic-t',2,leic-t0206).
evento(433,'sistemas operativos',laboratorial,20,'1-27').
horario(433,terca-feira,12.5,14.0,1.5,p2).
turno(433,'leic-t',2,leic-t0206).
evento(434,'sistemas operativos',laboratorial,20,'1-15').
horario(434,quinta-feira,12.5,14.0,1.5,p2).
turno(434,'leic-t',2,leic-t0206).
evento(435,'sistemas operativos',laboratorial,15,'0-27').
horario(435,sexta-feira,13.0,14.5,1.5,p2).
turno(435,leti,2,leti0204).
evento(436,'sistemas operativos',laboratorial,15,'0-21').
horario(436,segunda-feira,16.0,17.5,1.5,p2).
turno(436,leti,2,leti0204).
evento(437,'sistemas operativos',laboratorial,16,'0-14').
horario(437,terca-feira,13.0,14.5,1.5,p2).
turno(437,leti,2,leti0202).
evento(438,'sistemas operativos',laboratorial,16,'0-14').
horario(438,sexta-feira,13.0,14.5,1.5,p2).
turno(438,leti,2,leti0202).
evento(439,'sistemas operativos',laboratorial,20,'1-17').
horario(439,quinta-feira,13.0,14.5,1.5,p2).
turno(439,'leic-t',2,leic-t0202).
evento(440,'sistemas operativos',laboratorial,20,'1-15').
horario(440,segunda-feira,17.5,19.0,1.5,p2).
turno(440,'leic-t',2,leic-t0202).
evento(441,'sistemas operativos',laboratorial,20,'1-17').
horario(441,quinta-feira,12.5,14.0,1.5,p2).
turno(441,'leic-t',2,leic-t0202).
evento(442,'sistemas operativos',laboratorial,17,'1-17').
horario(442,segunda-feira,16.0,17.5,1.5,p2).
turno(442,leti,2,leti0203).
evento(443,'sistemas operativos',laboratorial,17,'0-14').
horario(443,quarta-feira,13.0,14.5,1.5,p2).
turno(443,leti,2,leti0203).
evento(444,'sistemas operativos',laboratorial,17,'0-27').
horario(444,quinta-feira,10.5,12.0,1.5,p2).
turno(444,'leic-t',2,leic-t0205).
turno(444,'leic-t',2,leic-t0203).
evento(445,'sistemas operativos',laboratorial,17,'1-27').
horario(445,terca-feira,10.5,12.0,1.5,p2).
turno(445,'leic-t',2,leic-t0205).
turno(445,'leic-t',2,leic-t0203).
evento(446,'sistemas operativos',teorica,116,a1).
horario(446,quarta-feira,15.5,17.5,2.0,p2).
turno(446,'leic-t',2,leic-t0206).
turno(446,'leic-t',2,leic-t0205).
turno(446,'leic-t',2,leic-t0202).
turno(446,'leic-t',2,leic-t0204).
turno(446,'leic-t',2,leic-t0201).
turno(446,'leic-t',2,leic-t0203).
evento(447,'sistemas operativos',teorica,116,a1).
horario(447,quinta-feira,14.5,15.5,1.0,indeterminado).
turno(447,'leic-t',2,leic-t0206).
turno(447,'leic-t',2,leic-t0205).
turno(447,'leic-t',2,leic-t0202).
turno(447,'leic-t',2,leic-t0204).
turno(447,'leic-t',2,leic-t0201).
turno(447,'leic-t',2,leic-t0203).
evento(448,'sistemas operativos',teorica,116,a1).
horario(448,sexta-feira,15.5,16.5,1.0,p2).
turno(448,'leic-t',2,leic-t0206).
turno(448,'leic-t',2,leic-t0205).
turno(448,'leic-t',2,leic-t0202).
turno(448,'leic-t',2,leic-t0204).
turno(448,'leic-t',2,leic-t0201).
turno(448,'leic-t',2,leic-t0203).
evento(449,'sistemas operativos',teorica,116,a1).
horario(449,terca-feira,14.0,15.0,1.0,p2).
turno(449,'leic-t',2,leic-t0206).
turno(449,'leic-t',2,leic-t0205).
turno(449,'leic-t',2,leic-t0202).
turno(449,'leic-t',2,leic-t0204).
turno(449,'leic-t',2,leic-t0201).
turno(449,'leic-t',2,leic-t0203).
evento(450,'sistemas operativos',teorica,116,a1).
horario(450,quinta-feira,14.0,15.0,1.0,p2).
turno(450,'leic-t',2,leic-t0206).
turno(450,'leic-t',2,leic-t0205).
turno(450,'leic-t',2,leic-t0202).
turno(450,'leic-t',2,leic-t0204).
turno(450,'leic-t',2,leic-t0201).
turno(450,'leic-t',2,leic-t0203).
evento(451,'sistemas operativos',laboratorial,4,'1-19').
horario(451,segunda-feira,17.5,19.0,1.5,p2).
turno(451,'leic-t',2,leic-t0205).
evento(452,'sistemas operativos',laboratorial,4,'0-14').
horario(452,quinta-feira,15.5,17.0,1.5,p2).
turno(452,'leic-t',2,leic-t0205).
evento(453,'sistemas operativos',laboratorial,19,'0-14').
horario(453,segunda-feira,16.0,17.5,1.5,p2).
turno(453,leti,2,leti0201).
evento(454,'sistemas operativos',laboratorial,19,'1-15').
horario(454,sexta-feira,13.0,14.5,1.5,p2).
turno(454,leti,2,leti0201).
evento(455,'sistemas operativos',laboratorial,19,'1-17').
horario(455,quinta-feira,15.5,17.0,1.5,p2).
turno(455,'leic-t',2,leic-t0203).
evento(456,'sistemas operativos',laboratorial,19,'1-17').
horario(456,terca-feira,12.5,14.0,1.5,p2).
turno(456,'leic-t',2,leic-t0203).
evento(457,'sistemas operativos',teorica,69,a1).
horario(457,sexta-feira,16.5,17.5,1.0,p2).
turno(457,leti,2,leti0201).
turno(457,leti,2,leti0203).
turno(457,leti,2,leti0202).
turno(457,leti,2,leti0204).
evento(458,'sistemas operativos',teorica,69,a1).
horario(458,segunda-feira,14.0,16.0,2.0,p2).
turno(458,leti,2,leti0201).
turno(458,leti,2,leti0203).
turno(458,leti,2,leti0202).
turno(458,leti,2,leti0204).
evento(459,'sistemas operativos',teorica,69,a1).
horario(459,quarta-feira,14.5,15.5,1.0,p2).
turno(459,leti,2,leti0201).
turno(459,leti,2,leti0203).
turno(459,leti,2,leti0202).
turno(459,leti,2,leti0204).
evento(460,'sistemas operativos',teorica,69,a1).
horario(460,terca-feira,16.5,17.5,1.0,p2).
turno(460,leti,2,leti0201).
turno(460,leti,2,leti0203).
turno(460,leti,2,leti0202).
turno(460,leti,2,leti0204).
evento(461,'sistemas operativos',laboratorial,15,'1-15').
horario(461,quinta-feira,15.5,17.0,1.5,p2).
turno(461,'leic-t',2,leic-t0201).
evento(462,'sistemas operativos',laboratorial,15,'1-17').
horario(462,segunda-feira,17.5,19.0,1.5,p2).
turno(462,'leic-t',2,leic-t0201).
evento(463,'sistemas operativos',laboratorial,15,'0-27').
horario(463,terca-feira,10.5,12.0,1.5,p2).
turno(463,'leic-t',2,leic-t0204).
evento(464,'sistemas operativos',laboratorial,15,'1-17').
horario(464,quinta-feira,10.5,12.0,1.5,p2).
turno(464,'leic-t',2,leic-t0204).
evento(465,'visualizacao de informacao',teorica,26,'1-24').
horario(465,segunda-feira,15.5,17.5,2.0,p1).
turno(465,'meic-t',1,meic-t0101).
evento(466,'visualizacao de informacao',teorica,26,'1-24').
horario(466,quinta-feira,15.5,17.5,2.0,p1).
turno(466,'meic-t',1,meic-t0101).
evento(467,'visualizacao de informacao',laboratorial,17,'0-23').
horario(467,quinta-feira,11.5,13.0,1.5,p1).
turno(467,'meic-t',1,meic-t0101).
evento(468,'visualizacao de informacao',laboratorial,17,'0-16').
horario(468,sexta-feira,10.5,12.0,1.5,p1).
turno(468,'meic-t',1,meic-t0101).
evento(469,'visualizacao de informacao',laboratorial,9,'0-16').
horario(469,sexta-feira,12.0,13.5,1.5,p1).
turno(469,'meic-t',1,meic-t0101).
evento(470,'visualizacao de informacao',laboratorial,9,'0-23').
horario(470,quarta-feira,9.5,11.0,1.5,p1).
turno(470,'meic-t',1,meic-t0101).
evento(471,'analise e modelacao de sistemas',laboratorial,16,'0-17').
horario(471,sexta-feira,9.0,10.5,1.5,p2).
turno(471,'leic-t',3,leic-t0303).
evento(472,'analise e modelacao de sistemas',laboratorial,16,'0-9').
horario(472,terca-feira,8.0,9.5,1.5,p2).
turno(472,'leic-t',3,leic-t0303).
evento(473,'analise e modelacao de sistemas',laboratorial,25,'1-22').
horario(473,quarta-feira,11.0,12.5,1.5,p2).
turno(473,'leic-t',3,leic-t0301).
evento(474,'analise e modelacao de sistemas',laboratorial,25,'1-11').
horario(474,segunda-feira,11.0,12.5,1.5,p2).
turno(474,'leic-t',3,leic-t0301).
evento(475,'analise e modelacao de sistemas',laboratorial,23,'0-16').
horario(475,sexta-feira,9.0,10.5,1.5,p2).
turno(475,'leic-t',3,leic-t0302).
evento(476,'analise e modelacao de sistemas',laboratorial,23,'0-23').
horario(476,terca-feira,8.0,9.5,1.5,p2).
turno(476,'leic-t',3,leic-t0302).
evento(477,'analise e modelacao de sistemas',laboratorial,26,'1-2').
horario(477,quarta-feira,11.0,12.5,1.5,p2).
turno(477,'leic-t',3,leic-t0304).
evento(478,'analise e modelacao de sistemas',laboratorial,26,'0-23').
horario(478,segunda-feira,11.0,12.5,1.5,p2).
turno(478,'leic-t',3,leic-t0304).
evento(479,'analise e modelacao de sistemas',teorica,88,a3).
horario(479,segunda-feira,9.0,11.0,2.0,p2).
turno(479,'leic-t',3,leic-t0302).
turno(479,'leic-t',3,leic-t0301).
turno(479,'leic-t',3,leic-t0304).
turno(479,'leic-t',3,leic-t0303).
evento(480,'analise e modelacao de sistemas',teorica,88,a4).
horario(480,quarta-feira,9.0,11.0,2.0,p2).
turno(480,'leic-t',3,leic-t0302).
turno(480,'leic-t',3,leic-t0301).
turno(480,'leic-t',3,leic-t0304).
turno(480,'leic-t',3,leic-t0303).
evento(481,'bioengenharia de sistemas',seminario,2,'1-75').
horario(481,segunda-feira,14.0,15.0,1.0,p2).
turno(481,mbmrp,2,mbmrp0201).
evento(482,'bioengenharia de sistemas',teorica,5,'1-75').
horario(482,segunda-feira,15.0,17.0,2.0,p2).
turno(482,mbmrp,2,mbmrp0201).
evento(483,'bioengenharia de sistemas','teorico-pratica',0,'1-75').
horario(483,terca-feira,10.0,12.0,2.0,p2).
turno(483,mbmrp,2,mbmrp0201).
evento(484,'bioengenharia de sistemas',teorica,9,'1-75').
horario(484,terca-feira,12.0,13.0,1.0,p2).
turno(484,mbmrp,2,mbmrp0201).
evento(485,'organizacao industrial',teorica,70,a4).
horario(485,quinta-feira,10.5,12.5,2.0,p1_2).
turno(485,megi,2,megi0202).
turno(485,megi,2,megi0201).
evento(486,'organizacao industrial',pratica,68,'0-65').
horario(486,quinta-feira,9.0,10.5,1.5,p1_2).
turno(486,megi,2,megi0202).
turno(486,megi,2,megi0201).
evento(487,electrotecnia,laboratorial,4,'1-64').
horario(487,terca-feira,8.0,10.0,2.0,indeterminado).
turno(487,lee,3,lee0301).
turno(487,lee,3,lee0302).
evento(488,electrotecnia,'teorico-pratica',10,'1-2').
horario(488,quinta-feira,14.0,16.0,2.0,p2).
turno(488,lee,3,lee0301).
turno(488,lee,3,lee0302).
evento(489,electrotecnia,'teorico-pratica',10,'0-9').
horario(489,terca-feira,13.0,15.0,2.0,p2).
turno(489,lee,3,lee0301).
turno(489,lee,3,lee0302).
evento(490,electrotecnia,'teorico-pratica',10,'0-15').
horario(490,terca-feira,10.0,12.0,2.0,p2).
turno(490,lee,3,lee0301).
turno(490,lee,3,lee0302).
evento(491,electrotecnia,laboratorial,0,'1-64').
horario(491,terca-feira,8.0,10.0,2.0,p2).
turno(491,lee,3,lee0302).
evento(492,electrotecnia,laboratorial,6,'1-64').
horario(492,quinta-feira,9.0,11.0,2.0,p2).
turno(492,lee,3,lee0301).
evento(493,'aprendizagem profunda (dei)',teorica,51,'1-2').
horario(493,quarta-feira,14.0,16.0,2.0,p2).
turno(493,'meic-t',1,meic-t0101).
evento(494,'aprendizagem profunda (dei)',teorica,51,'1-2').
horario(494,sexta-feira,10.0,12.0,2.0,p2).
turno(494,'meic-t',1,meic-t0101).
evento(495,'aprendizagem profunda (dei)',laboratorial,18,'0-21').
horario(495,quinta-feira,10.0,11.5,1.5,p2).
turno(495,'meic-t',1,meic-t0101).
evento(496,'aprendizagem profunda (dei)',laboratorial,18,'1-19').
horario(496,terca-feira,17.0,18.5,1.5,p2).
turno(496,'meic-t',1,meic-t0101).
evento(497,'aprendizagem profunda (dei)',laboratorial,27,'1-15').
horario(497,terca-feira,15.0,16.5,1.5,p2).
turno(497,'meic-t',1,meic-t0101).
evento(498,'aprendizagem profunda (dei)',laboratorial,27,'1-19').
horario(498,sexta-feira,12.0,13.5,1.5,p2).
turno(498,'meic-t',1,meic-t0101).
evento(499,'seguranca informatica em redes e sistemas',teorica,41,'1-24').
horario(499,quarta-feira,9.0,11.0,2.0,p2).
turno(499,'meic-t',1,meic-t0101).
evento(500,'seguranca informatica em redes e sistemas',teorica,41,'1-22').
horario(500,terca-feira,13.5,15.5,2.0,p2).
turno(500,'meic-t',1,meic-t0101).
evento(501,'seguranca informatica em redes e sistemas',laboratorial,18,'0-14').
horario(501,sexta-feira,14.5,17.5,3.0,p2).
turno(501,'meic-t',1,meic-t0101).
evento(502,'seguranca informatica em redes e sistemas',laboratorial,24,'0-14').
horario(502,quinta-feira,8.5,11.5,3.0,p2).
turno(502,'meic-t',1,meic-t0101).
evento(503,'ciencia de dados',laboratorial,0,'1-19').
horario(503,quinta-feira,16.0,17.5,1.5,p2).
turno(503,'meic-t',1,meic-t0101).
evento(504,'ciencia de dados',laboratorial,0,'1-19').
horario(504,quinta-feira,14.5,16.0,1.5,p2).
turno(504,'meic-t',1,meic-t0101).
evento(505,'ciencia de dados',laboratorial,0,'1-19').
horario(505,quinta-feira,11.0,12.5,1.5,p2).
turno(505,'meic-t',1,meic-t0101).
evento(506,'ciencia de dados',laboratorial,0,'1-19').
horario(506,quinta-feira,12.5,14.0,1.5,p2).
turno(506,'meic-t',1,meic-t0101).
evento(507,'ciencia de dados',laboratorial,20,'1-19').
horario(507,terca-feira,11.0,12.5,1.5,p2).
turno(507,megi,2,megi0201).
turno(507,meti,1,merc0101).
turno(507,'meic-t',1,meic-t0101).
evento(508,'ciencia de dados',laboratorial,20,'1-15').
horario(508,terca-feira,12.5,14.0,1.5,p2).
turno(508,megi,2,megi0201).
turno(508,meti,1,merc0101).
turno(508,'meic-t',1,meic-t0101).
evento(509,'ciencia de dados',laboratorial,17,'1-17').
horario(509,terca-feira,14.0,15.5,1.5,p2).
turno(509,'meic-t',1,meic-t0101).
evento(510,'ciencia de dados',laboratorial,17,'1-19').
horario(510,terca-feira,12.5,14.0,1.5,p2).
turno(510,'meic-t',1,meic-t0101).
evento(511,'ciencia de dados',teorica,77,a5).
horario(511,terca-feira,9.0,11.0,2.0,p2).
turno(511,megi,2,megi0201).
turno(511,meti,1,merc0101).
turno(511,'meic-t',1,meic-t0101).
evento(512,'ciencia de dados',teorica,77,'0-65').
horario(512,segunda-feira,10.0,12.0,2.0,p2).
turno(512,megi,2,megi0201).
turno(512,meti,1,merc0101).
turno(512,'meic-t',1,meic-t0101).
evento(513,'biologia computacional',laboratorial,14,'1-15').
horario(513,quinta-feira,11.5,13.0,1.5,p1).
turno(513,mbmrp,1,mbmrp0103).
turno(513,mbmrp,1,mbmrp0102).
turno(513,mbmrp,1,mbmrp0101).
evento(514,'biologia computacional',laboratorial,14,'1-15').
horario(514,segunda-feira,15.5,17.0,1.5,p1).
turno(514,mbmrp,1,mbmrp0103).
turno(514,mbmrp,1,mbmrp0102).
turno(514,mbmrp,1,mbmrp0101).
evento(515,'biologia computacional',laboratorial,14,'1-19').
horario(515,quinta-feira,12.0,13.5,1.5,p1).
turno(515,mbmrp,1,mbmrp0103).
turno(515,mbmrp,1,mbmrp0102).
turno(515,mbmrp,1,mbmrp0101).
evento(516,'biologia computacional',laboratorial,14,'1-15').
horario(516,quinta-feira,11.5,13.0,1.5,p1).
turno(516,mbmrp,1,mbmrp0103).
turno(516,mbmrp,1,mbmrp0102).
turno(516,mbmrp,1,mbmrp0101).
evento(517,'biologia computacional',laboratorial,14,'1-15').
horario(517,quinta-feira,9.5,11.5,2.0,p1).
turno(517,mbmrp,1,mbmrp0103).
turno(517,mbmrp,1,mbmrp0102).
turno(517,mbmrp,1,mbmrp0101).
evento(518,'biologia computacional',teorica,34,'0-19').
horario(518,sexta-feira,13.0,15.0,2.0,p1).
turno(518,mbmrp,1,mbmrp0103).
turno(518,mbmrp,1,mbmrp0102).
turno(518,mbmrp,1,mbmrp0101).
evento(519,'biologia computacional',teorica,34,'0-19').
horario(519,terca-feira,18.0,20.0,2.0,p1).
turno(519,mbmrp,1,mbmrp0103).
turno(519,mbmrp,1,mbmrp0102).
turno(519,mbmrp,1,mbmrp0101).
evento(520,marketing,pratica,30,'0-73').
horario(520,terca-feira,8.5,10.0,1.5,p2).
turno(520,legi,3,legi0304).
turno(520,legi,3,legi0301).
evento(521,marketing,pratica,30,'0-17').
horario(521,terca-feira,12.0,13.5,1.5,p2).
turno(521,legi,3,legi0305).
turno(521,legi,3,legi0302).
evento(522,marketing,teorica,62,a3).
horario(522,terca-feira,10.0,12.0,2.0,p2).
turno(522,legi,3,legi0303).
turno(522,legi,3,legi0304).
turno(522,legi,3,legi0301).
turno(522,legi,3,legi0305).
turno(522,legi,3,legi0302).
evento(523,'redes de comunicacoes moveis',laboratorial,0,'1-28').
horario(523,quinta-feira,13.5,15.0,1.5,p1).
turno(523,mee,2,mee0201).
turno(523,meti,1,merc0101).
evento(524,'redes de comunicacoes moveis',laboratorial,6,'1-28').
horario(524,quinta-feira,12.0,13.5,1.5,p1).
turno(524,mee,2,mee0201).
turno(524,meti,1,merc0101).
evento(525,'redes de comunicacoes moveis',teorica,6,'1-4').
horario(525,quinta-feira,10.0,12.0,2.0,p1).
turno(525,mee,2,mee0201).
turno(525,meti,1,merc0101).
evento(526,'redes de comunicacoes moveis',teorica,6,a5).
horario(526,terca-feira,9.5,11.5,2.0,p1).
turno(526,mee,2,mee0201).
turno(526,meti,1,merc0101).
evento(527,'gestao (legi)',teorica,90,a5).
horario(527,sexta-feira,8.0,10.0,2.0,p1).
turno(527,legi,1,legi0104).
turno(527,legi,1,legi0101).
turno(527,legi,1,legi0105).
turno(527,legi,1,legi0102).
turno(527,legi,1,legi0103).
evento(528,'gestao (legi)',pratica,25,'1-4').
horario(528,sexta-feira,10.0,11.5,1.5,p1).
turno(528,legi,1,legi0105).
evento(529,'gestao (legi)',pratica,34,'0-17').
horario(529,segunda-feira,10.0,11.5,1.5,p1).
turno(529,legi,1,legi0104).
turno(529,legi,1,legi0101).
evento(530,'gestao (legi)',pratica,29,'0-73').
horario(530,segunda-feira,13.0,14.5,1.5,p1).
turno(530,legi,1,legi0102).
turno(530,legi,1,legi0103).
evento(531,'algebra linear','teorico-pratica',61,a5).
horario(531,segunda-feira,14.5,16.5,2.0,p1_2).
turno(531,legi,1,legi0102).
turno(531,legi,1,legi0103).
turno(531,lee,1,lee0102).
turno(531,lee,1,lee0101).
evento(532,'algebra linear','teorico-pratica',61,a3).
horario(532,sexta-feira,10.0,12.0,2.0,p1_2).
turno(532,legi,1,legi0102).
turno(532,legi,1,legi0103).
turno(532,lee,1,lee0102).
turno(532,lee,1,lee0101).
evento(533,'algebra linear','teorico-pratica',65,a3).
horario(533,quarta-feira,9.5,11.5,2.0,p1_2).
turno(533,legi,1,legi0104).
turno(533,legi,1,legi0101).
turno(533,legi,1,legi0105).
turno(533,lee,1,lee0103).
evento(534,'algebra linear','teorico-pratica',65,a5).
horario(534,segunda-feira,12.0,14.0,2.0,p1_2).
turno(534,legi,1,legi0104).
turno(534,legi,1,legi0101).
turno(534,legi,1,legi0105).
turno(534,lee,1,lee0103).
evento(535,'sistemas industriais na era digital',teorica,58,a1).
horario(535,quarta-feira,10.5,12.5,2.0,p1).
turno(535,legi,3,legi0303).
turno(535,legi,3,legi0304).
turno(535,legi,3,legi0301).
turno(535,legi,3,legi0305).
turno(535,legi,3,legi0302).
evento(536,'sistemas industriais na era digital',teorica,58,a3).
horario(536,segunda-feira,12.0,13.0,1.0,p1).
turno(536,legi,3,legi0303).
turno(536,legi,3,legi0304).
turno(536,legi,3,legi0301).
turno(536,legi,3,legi0305).
turno(536,legi,3,legi0302).
evento(537,macroeconomia,pratica,18,'0-9').
horario(537,sexta-feira,11.0,12.0,1.0,p1).
turno(537,legi,2,legi0205).
evento(538,macroeconomia,teorica,83,a5).
horario(538,quarta-feira,15.5,16.5,1.0,p1).
turno(538,legi,2,legi0205).
turno(538,legi,2,legi0202).
turno(538,legi,2,legi0204).
turno(538,legi,2,legi0201).
turno(538,legi,2,legi0203).
evento(539,macroeconomia,teorica,83,a3).
horario(539,quinta-feira,13.5,15.5,2.0,p1).
turno(539,legi,2,legi0205).
turno(539,legi,2,legi0202).
turno(539,legi,2,legi0204).
turno(539,legi,2,legi0201).
turno(539,legi,2,legi0203).
evento(540,macroeconomia,pratica,30,'1-11').
horario(540,quarta-feira,16.5,17.5,1.0,p1).
turno(540,legi,2,legi0204).
turno(540,legi,2,legi0201).
evento(541,macroeconomia,pratica,30,'1-11').
horario(541,sexta-feira,14.5,15.5,1.0,p1).
turno(541,legi,2,legi0202).
turno(541,legi,2,legi0203).
evento(542,'sensores e actuadores','teorico-pratica',8,'0-73').
horario(542,quarta-feira,14.5,16.5,2.0,p2).
turno(542,mee,1,mee0101).
turno(542,meti,1,merc0101).
evento(543,'sensores e actuadores','teorico-pratica',8,'0-73').
horario(543,segunda-feira,14.0,16.0,2.0,p2).
turno(543,mee,1,mee0101).
turno(543,meti,1,merc0101).
evento(544,'sensores e actuadores',laboratorial,6,'1-64').
horario(544,segunda-feira,16.0,17.5,1.5,p2).
turno(544,mee,1,mee0101).
turno(544,meti,1,merc0101).
evento(545,'sensores e actuadores',laboratorial,2,'1-64').
horario(545,quarta-feira,16.5,18.0,1.5,p2).
turno(545,mee,1,mee0101).
turno(545,meti,1,merc0101).
evento(546,'administracao e gestao de infraestruturas e servicos de it',teorica,54,a3).
horario(546,sexta-feira,17.5,19.5,2.0,p1).
turno(546,meti,1,merc0101).
turno(546,'meic-t',1,meic-t0101).
evento(547,'administracao e gestao de infraestruturas e servicos de it',teorica,54,a4).
horario(547,segunda-feira,11.0,13.0,2.0,p1).
turno(547,meti,1,merc0101).
turno(547,'meic-t',1,meic-t0101).
evento(548,'administracao e gestao de infraestruturas e servicos de it',laboratorial,18,'0-27').
horario(548,terca-feira,13.5,16.5,3.0,p1).
turno(548,meti,1,merc0101).
turno(548,'meic-t',1,meic-t0101).
evento(549,'administracao e gestao de infraestruturas e servicos de it',laboratorial,18,'0-27').
horario(549,terca-feira,8.0,11.0,3.0,p1).
turno(549,'meic-t',1,meic-t0101).
evento(550,'fundamentos da programacao',laboratorial,22,'0-23').
horario(550,quinta-feira,8.0,10.0,2.0,p1).
turno(550,'leic-t',1,leic-t0107).
turno(550,'leic-t',1,leic-t0105).
evento(551,'fundamentos da programacao',laboratorial,22,'0-23').
horario(551,segunda-feira,11.0,13.0,2.0,p1).
turno(551,'leic-t',1,leic-t0107).
turno(551,'leic-t',1,leic-t0105).
evento(552,'fundamentos da programacao',laboratorial,20,'0-15').
horario(552,terca-feira,11.5,13.5,2.0,p1).
turno(552,'leic-t',1,leic-t0102).
evento(553,'fundamentos da programacao',laboratorial,20,'0-25').
horario(553,quinta-feira,11.0,13.0,2.0,p1).
turno(553,'leic-t',1,leic-t0102).
evento(554,'fundamentos da programacao',laboratorial,18,'0-9').
horario(554,segunda-feira,11.0,13.0,2.0,p1).
turno(554,'leic-t',1,leic-t0103).
evento(555,'fundamentos da programacao',laboratorial,18,'0-15').
horario(555,quinta-feira,8.0,10.0,2.0,p1).
turno(555,'leic-t',1,leic-t0103).
evento(556,'fundamentos da programacao',teorica,48,a2).
horario(556,sexta-feira,10.0,11.0,1.0,p1).
turno(556,leti,1,leti0103).
turno(556,leti,1,leti0102).
turno(556,leti,1,leti0101).
evento(557,'fundamentos da programacao',teorica,48,a2).
horario(557,quarta-feira,10.5,11.5,1.0,p1).
turno(557,leti,1,leti0103).
turno(557,leti,1,leti0102).
turno(557,leti,1,leti0101).
evento(558,'fundamentos da programacao',teorica,48,a2).
horario(558,quinta-feira,11.5,12.5,1.0,p1).
turno(558,leti,1,leti0103).
turno(558,leti,1,leti0102).
turno(558,leti,1,leti0101).
evento(559,'fundamentos da programacao',teorica,48,a2).
horario(559,terca-feira,9.0,10.0,1.0,p1).
turno(559,leti,1,leti0103).
turno(559,leti,1,leti0102).
turno(559,leti,1,leti0101).
evento(560,'fundamentos da programacao',teorica,48,a3).
horario(560,segunda-feira,11.0,12.0,1.0,p1).
turno(560,leti,1,leti0103).
turno(560,leti,1,leti0102).
turno(560,leti,1,leti0101).
evento(561,'fundamentos da programacao',laboratorial,16,'0-23').
horario(561,sexta-feira,11.0,13.0,2.0,p1).
turno(561,leti,1,leti0103).
evento(562,'fundamentos da programacao',laboratorial,16,'0-9').
horario(562,segunda-feira,9.0,11.0,2.0,p1).
turno(562,leti,1,leti0103).
evento(563,'fundamentos da programacao',teorica,110,a5).
horario(563,segunda-feira,10.0,11.0,1.0,p1).
turno(563,'leic-t',1,leic-t0107).
turno(563,'leic-t',1,leic-t0105).
turno(563,'leic-t',1,leic-t0104).
turno(563,'leic-t',1,leic-t0103).
turno(563,'leic-t',1,leic-t0101).
turno(563,'leic-t',1,leic-t0102).
turno(563,'leic-t',1,leic-t0106).
evento(564,'fundamentos da programacao',teorica,110,a2).
horario(564,quinta-feira,10.0,11.0,1.0,p1).
turno(564,'leic-t',1,leic-t0107).
turno(564,'leic-t',1,leic-t0105).
turno(564,'leic-t',1,leic-t0104).
turno(564,'leic-t',1,leic-t0103).
turno(564,'leic-t',1,leic-t0101).
turno(564,'leic-t',1,leic-t0102).
turno(564,'leic-t',1,leic-t0106).
evento(565,'fundamentos da programacao',teorica,110,a2).
horario(565,terca-feira,10.5,11.5,1.0,p1).
turno(565,'leic-t',1,leic-t0107).
turno(565,'leic-t',1,leic-t0105).
turno(565,'leic-t',1,leic-t0104).
turno(565,'leic-t',1,leic-t0103).
turno(565,'leic-t',1,leic-t0101).
turno(565,'leic-t',1,leic-t0102).
turno(565,'leic-t',1,leic-t0106).
evento(566,'fundamentos da programacao',teorica,110,a2).
horario(566,quarta-feira,9.5,10.5,1.0,p1).
turno(566,'leic-t',1,leic-t0107).
turno(566,'leic-t',1,leic-t0105).
turno(566,'leic-t',1,leic-t0104).
turno(566,'leic-t',1,leic-t0103).
turno(566,'leic-t',1,leic-t0101).
turno(566,'leic-t',1,leic-t0102).
turno(566,'leic-t',1,leic-t0106).
evento(567,'fundamentos da programacao',teorica,110,a3).
horario(567,sexta-feira,9.0,10.0,1.0,p1).
turno(567,'leic-t',1,leic-t0107).
turno(567,'leic-t',1,leic-t0105).
turno(567,'leic-t',1,leic-t0104).
turno(567,'leic-t',1,leic-t0103).
turno(567,'leic-t',1,leic-t0101).
turno(567,'leic-t',1,leic-t0102).
turno(567,'leic-t',1,leic-t0106).
evento(568,'fundamentos da programacao',laboratorial,16,'0-16').
horario(568,terca-feira,11.5,13.5,2.0,p1).
turno(568,'leic-t',1,leic-t0104).
evento(569,'fundamentos da programacao',laboratorial,16,'1-3').
horario(569,quinta-feira,11.0,13.0,2.0,p1).
turno(569,'leic-t',1,leic-t0104).
evento(570,'fundamentos da programacao',laboratorial,16,'0-17').
horario(570,quinta-feira,11.0,13.0,2.0,p1).
turno(570,'leic-t',1,leic-t0106).
evento(571,'fundamentos da programacao',laboratorial,16,'0-9').
horario(571,terca-feira,11.5,13.5,2.0,p1).
turno(571,'leic-t',1,leic-t0106).
evento(572,'fundamentos da programacao',laboratorial,12,'0-23').
horario(572,segunda-feira,9.0,11.0,2.0,p1).
turno(572,leti,1,leti0101).
evento(573,'fundamentos da programacao',laboratorial,12,'0-25').
horario(573,segunda-feira,9.0,11.0,2.0,p1).
turno(573,leti,1,leti0102).
evento(574,'fundamentos da programacao',laboratorial,22,'0-9').
horario(574,quinta-feira,8.0,10.0,2.0,p1).
turno(574,'leic-t',1,leic-t0101).
evento(575,'fundamentos da programacao',laboratorial,22,'0-25').
horario(575,segunda-feira,11.0,13.0,2.0,p1).
turno(575,'leic-t',1,leic-t0101).
evento(576,'analitica empresarial',pratica,27,'1-2').
horario(576,quarta-feira,13.5,15.0,1.5,p1).
turno(576,legi,3,legi0305).
turno(576,legi,3,legi0302).
evento(577,'analitica empresarial',pratica,27,'0-17').
horario(577,terca-feira,11.0,12.5,1.5,p1).
turno(577,legi,3,legi0305).
turno(577,legi,3,legi0302).
evento(578,'analitica empresarial',pratica,25,'1-11').
horario(578,quarta-feira,9.0,10.5,1.5,p1).
turno(578,legi,3,legi0304).
turno(578,legi,3,legi0301).
evento(579,'analitica empresarial',pratica,25,'0-9').
horario(579,quinta-feira,13.0,14.5,1.5,p1).
turno(579,legi,3,legi0304).
turno(579,legi,3,legi0301).
evento(580,'analitica empresarial',teorica,68,a4).
horario(580,terca-feira,9.0,11.0,2.0,p1).
turno(580,legi,3,legi0303).
turno(580,legi,3,legi0304).
turno(580,legi,3,legi0301).
turno(580,legi,3,legi0305).
turno(580,legi,3,legi0302).
evento(581,'analitica empresarial',teorica,68,a5).
horario(581,segunda-feira,11.0,12.0,1.0,p1).
turno(581,legi,3,legi0303).
turno(581,legi,3,legi0304).
turno(581,legi,3,legi0301).
turno(581,legi,3,legi0305).
turno(581,legi,3,legi0302).
evento(582,'analitica empresarial',pratica,16,'0-17').
horario(582,segunda-feira,14.0,15.5,1.5,p1).
turno(582,legi,3,legi0303).
evento(583,'analitica empresarial',pratica,16,'0-23').
horario(583,quinta-feira,10.0,11.5,1.5,p1).
turno(583,legi,3,legi0303).
evento(584,'analise de dados e modelacao estatistica','teorico-pratica',21,'1-24').
horario(584,sexta-feira,8.5,10.5,2.0,p2).
turno(584,leti,3,leti0303).
turno(584,leti,3,leti0302).
turno(584,leti,3,leti0301).
evento(585,'analise de dados e modelacao estatistica','teorico-pratica',21,a5).
horario(585,quinta-feira,10.5,12.5,2.0,p2).
turno(585,leti,3,leti0303).
turno(585,leti,3,leti0302).
turno(585,leti,3,leti0301).
evento(586,'analise de dados e modelacao estatistica',laboratorial,20,'0-23').
horario(586,quinta-feira,9.0,10.5,1.5,p2).
turno(586,leti,3,leti0303).
turno(586,leti,3,leti0302).
turno(586,leti,3,leti0301).
evento(587,'analise de dados e modelacao estatistica',laboratorial,20,'0-23').
horario(587,sexta-feira,10.5,12.0,1.5,p2).
turno(587,leti,3,leti0303).
turno(587,leti,3,leti0302).
turno(587,leti,3,leti0301).
evento(588,'calculo diferencial e integral iii','teorico-pratica',67,a4).
horario(588,segunda-feira,15.5,17.5,2.0,p1_2).
turno(588,legi,2,legi0205).
turno(588,legi,2,legi0204).
turno(588,legi,2,legi0201).
turno(588,lee,2,lee0202).
evento(589,'calculo diferencial e integral iii','teorico-pratica',67,a1).
horario(589,sexta-feira,12.5,14.5,2.0,p1_2).
turno(589,legi,2,legi0205).
turno(589,legi,2,legi0204).
turno(589,legi,2,legi0201).
turno(589,lee,2,lee0202).
evento(590,'calculo diferencial e integral iii','teorico-pratica',69,a5).
horario(590,sexta-feira,14.5,16.5,2.0,p1_2).
turno(590,leti,2,leti0201).
turno(590,leti,2,leti0203).
turno(590,leti,2,leti0202).
turno(590,leti,2,leti0204).
evento(591,'calculo diferencial e integral iii','teorico-pratica',69,a4).
horario(591,quinta-feira,13.0,15.0,2.0,p1_2).
turno(591,leti,2,leti0201).
turno(591,leti,2,leti0203).
turno(591,leti,2,leti0202).
turno(591,leti,2,leti0204).
evento(592,'calculo diferencial e integral iii','teorico-pratica',67,a4).
horario(592,quinta-feira,16.0,18.0,2.0,p1_2).
turno(592,'leic-t',2,leic-t0206).
turno(592,'leic-t',2,leic-t0202).
turno(592,'leic-t',2,leic-t0204).
evento(593,'calculo diferencial e integral iii','teorico-pratica',67,'1-2').
horario(593,segunda-feira,10.0,12.0,2.0,p1_2).
turno(593,'leic-t',2,leic-t0206).
turno(593,'leic-t',2,leic-t0202).
turno(593,'leic-t',2,leic-t0204).
evento(594,'calculo diferencial e integral iii','teorico-pratica',63,'0-75').
horario(594,sexta-feira,10.0,12.0,2.0,p1_2).
turno(594,legi,2,legi0202).
turno(594,legi,2,legi0203).
turno(594,lee,2,lee0201).
evento(595,'calculo diferencial e integral iii','teorico-pratica',63,'0-75').
horario(595,terca-feira,11.0,13.0,2.0,p1_2).
turno(595,legi,2,legi0202).
turno(595,legi,2,legi0203).
turno(595,lee,2,lee0201).
evento(596,'calculo diferencial e integral iii','teorico-pratica',70,'1-2').
horario(596,quinta-feira,17.0,19.0,2.0,indeterminado).
turno(596,'leic-t',2,leic-t0205).
turno(596,'leic-t',2,leic-t0201).
turno(596,'leic-t',2,leic-t0203).
evento(597,'calculo diferencial e integral iii','teorico-pratica',70,a5).
horario(597,quarta-feira,13.0,15.0,2.0,p1_2).
turno(597,'leic-t',2,leic-t0205).
turno(597,'leic-t',2,leic-t0201).
turno(597,'leic-t',2,leic-t0203).
evento(598,'calculo diferencial e integral iii','teorico-pratica',70,a2).
horario(598,quinta-feira,17.0,19.0,2.0,p1_2).
turno(598,'leic-t',2,leic-t0205).
turno(598,'leic-t',2,leic-t0201).
turno(598,'leic-t',2,leic-t0203).
evento(599,'gestao de sistemas energeticos',problemas,40,'0-17').
horario(599,sexta-feira,10.5,12.0,1.5,p2).
turno(599,legi,3,legi0304).
turno(599,legi,3,legi0301).
evento(600,'gestao de sistemas energeticos',problemas,40,'1-4').
horario(600,segunda-feira,10.5,12.0,1.5,p2).
turno(600,legi,3,legi0304).
turno(600,legi,3,legi0301).
evento(601,'gestao de sistemas energeticos',teorica,82,a4).
horario(601,sexta-feira,12.0,14.0,2.0,p2).
turno(601,legi,3,legi0303).
turno(601,legi,3,legi0304).
turno(601,legi,3,legi0301).
turno(601,legi,3,legi0305).
turno(601,legi,3,legi0302).
evento(602,'gestao de sistemas energeticos',teorica,82,a3).
horario(602,quinta-feira,11.0,13.0,2.0,p2).
turno(602,legi,3,legi0303).
turno(602,legi,3,legi0304).
turno(602,legi,3,legi0301).
turno(602,legi,3,legi0305).
turno(602,legi,3,legi0302).
evento(603,'gestao de sistemas energeticos',problemas,33,'1-4').
horario(603,sexta-feira,9.0,10.5,1.5,p2).
turno(603,legi,3,legi0303).
evento(604,'gestao de sistemas energeticos',problemas,33,'0-17').
horario(604,segunda-feira,9.0,10.5,1.5,p2).
turno(604,legi,3,legi0303).
evento(605,'inteligencia artificial para jogos',laboratorial,14,'1-32').
horario(605,quinta-feira,14.0,17.0,3.0,p1).
turno(605,'meic-t',1,meic-t0101).
evento(606,'inteligencia artificial para jogos',teorica,20,'0-19').
horario(606,terca-feira,13.5,15.5,2.0,p1).
turno(606,'meic-t',1,meic-t0101).
evento(607,'inteligencia artificial para jogos',teorica,20,'0-19').
horario(607,quinta-feira,17.0,19.0,2.0,p1).
turno(607,'meic-t',1,meic-t0101).
evento(608,'realidade virtual',teorica,13,'0-19').
horario(608,segunda-feira,14.5,16.5,2.0,p2).
turno(608,'meic-t',1,meic-t0101).
evento(609,'realidade virtual',teorica,13,'0-19').
horario(609,terca-feira,10.5,12.5,2.0,p2).
turno(609,'meic-t',1,meic-t0101).
evento(610,'realidade virtual',laboratorial,7,'1-27').
horario(610,quarta-feira,8.5,11.5,3.0,p2).
turno(610,'meic-t',1,meic-t0101).
evento(611,'estudio de design de interacao',laboratorial,10,'1-19').
horario(611,quinta-feira,14.0,17.0,3.0,p1).
turno(611,meti,1,merc0101).
turno(611,'meic-t',1,meic-t0101).
evento(612,'estudio de design de interacao',teorica,19,'0-19').
horario(612,quarta-feira,16.0,18.0,2.0,p1).
turno(612,meti,1,merc0101).
turno(612,'meic-t',1,meic-t0101).
evento(613,'estudio de design de interacao',teorica,19,'0-19').
horario(613,terca-feira,16.0,18.0,2.0,p1).
turno(613,meti,1,merc0101).
turno(613,'meic-t',1,meic-t0101).
evento(614,'desenho e modelacao geometrica',laboratorial,42,'1-4').
horario(614,sexta-feira,12.0,14.0,2.0,p2).
turno(614,lee,1,lee0103).
turno(614,lee,1,lee0102).
turno(614,lee,1,lee0101).
evento(615,'desenho e modelacao geometrica',laboratorial,42,'1-4').
horario(615,quinta-feira,13.0,15.0,2.0,p2).
turno(615,lee,1,lee0103).
turno(615,lee,1,lee0102).
turno(615,lee,1,lee0101).
evento(616,'desenho e modelacao geometrica',laboratorial,25,'0-25').
horario(616,quarta-feira,11.5,13.5,2.0,p2).
turno(616,legi,1,legi0103).
evento(617,'desenho e modelacao geometrica',laboratorial,25,'1-2').
horario(617,quinta-feira,11.0,13.0,2.0,p2).
turno(617,legi,1,legi0103).
evento(618,'desenho e modelacao geometrica',laboratorial,40,'1-4').
horario(618,quinta-feira,11.0,13.0,2.0,p2).
turno(618,legi,1,legi0104).
turno(618,legi,1,legi0101).
evento(619,'desenho e modelacao geometrica',laboratorial,40,'1-4').
horario(619,terca-feira,10.0,12.0,2.0,p2).
turno(619,legi,1,legi0104).
turno(619,legi,1,legi0101).
evento(620,'desenho e modelacao geometrica',laboratorial,39,'0-17').
horario(620,quarta-feira,11.5,13.5,2.0,indeterminado).
turno(620,legi,1,legi0105).
turno(620,legi,1,legi0102).
evento(621,'desenho e modelacao geometrica',laboratorial,39,'1-4').
horario(621,terca-feira,8.0,10.0,2.0,p2).
turno(621,legi,1,legi0105).
turno(621,legi,1,legi0102).
evento(622,'desenho e modelacao geometrica',laboratorial,39,'1-24').
horario(622,quarta-feira,11.5,13.5,2.0,p2).
turno(622,legi,1,legi0105).
turno(622,legi,1,legi0102).
evento(623,'fisica ii',teorica,92,a5).
horario(623,quarta-feira,15.0,17.0,2.0,p2).
turno(623,legi,2,legi0205).
turno(623,legi,2,legi0202).
turno(623,legi,2,legi0204).
turno(623,legi,2,legi0201).
turno(623,legi,2,legi0203).
evento(624,'fisica ii',teorica,92,a1).
horario(624,segunda-feira,17.5,19.5,2.0,p2).
turno(624,legi,2,legi0205).
turno(624,legi,2,legi0202).
turno(624,legi,2,legi0204).
turno(624,legi,2,legi0201).
turno(624,legi,2,legi0203).
evento(625,'fisica ii','teorico-pratica',20,'0-17').
horario(625,sexta-feira,14.5,16.0,1.5,p2).
turno(625,legi,2,legi0201).
evento(626,'fisica ii','teorico-pratica',20,'0-15').
horario(626,quinta-feira,14.0,15.5,1.5,p2).
turno(626,legi,2,legi0201).
evento(627,'fisica ii','teorico-pratica',25,'0-17').
horario(627,sexta-feira,13.0,14.5,1.5,p2).
turno(627,legi,2,legi0205).
turno(627,legi,2,legi0202).
turno(627,legi,2,legi0204).
turno(627,legi,2,legi0203).
evento(628,'fisica ii','teorico-pratica',25,'0-9').
horario(628,segunda-feira,16.0,17.5,1.5,p2).
turno(628,legi,2,legi0205).
turno(628,legi,2,legi0202).
turno(628,legi,2,legi0204).
turno(628,legi,2,legi0203).
evento(629,'fisica ii','teorico-pratica',40,'0-23').
horario(629,segunda-feira,14.0,15.5,1.5,p2).
turno(629,legi,2,legi0205).
turno(629,legi,2,legi0202).
turno(629,legi,2,legi0204).
turno(629,legi,2,legi0203).
evento(630,'fisica ii','teorico-pratica',40,'0-16').
horario(630,quinta-feira,17.5,19.0,1.5,p2).
turno(630,legi,2,legi0205).
turno(630,legi,2,legi0202).
turno(630,legi,2,legi0204).
turno(630,legi,2,legi0203).
evento(631,'desenvolvimento de aplicacoes distribuidas',laboratorial,9,'1-17').
horario(631,quinta-feira,13.0,16.0,3.0,p1).
turno(631,'meic-t',1,meic-t0101).
evento(632,'desenvolvimento de aplicacoes distribuidas',laboratorial,20,'1-17').
horario(632,quinta-feira,10.0,13.0,3.0,p1).
turno(632,meti,1,merc0101).
turno(632,'meic-t',1,meic-t0101).
evento(633,'desenvolvimento de aplicacoes distribuidas',teorica,30,'0-16').
horario(633,quarta-feira,17.0,19.0,2.0,p1).
turno(633,meti,1,merc0101).
turno(633,'meic-t',1,meic-t0101).
evento(634,'desenvolvimento de aplicacoes distribuidas',teorica,30,'1-24').
horario(634,segunda-feira,8.5,10.5,2.0,p1).
turno(634,meti,1,merc0101).
turno(634,'meic-t',1,meic-t0101).
evento(635,'introducao aos circuitos e sistemas electronicos',laboratorial,21,'1-60').
horario(635,terca-feira,12.5,14.5,2.0,p2).
turno(635,leti,2,leti0201).
turno(635,leti,2,leti0203).
turno(635,leti,2,leti0202).
turno(635,leti,2,leti0204).
turno(635,leti,3,leti0303).
turno(635,leti,3,leti0302).
turno(635,leti,3,leti0301).
evento(636,'introducao aos circuitos e sistemas electronicos',teorica,131,a3).
horario(636,quarta-feira,16.5,18.5,2.0,p2).
turno(636,leti,2,leti0201).
turno(636,lee,2,lee0202).
turno(636,lee,2,lee0201).
turno(636,leti,2,leti0203).
turno(636,leti,2,leti0202).
turno(636,leti,2,leti0204).
turno(636,leti,3,leti0303).
turno(636,leti,3,leti0302).
turno(636,leti,3,leti0301).
evento(637,'introducao aos circuitos e sistemas electronicos',teorica,131,a2).
horario(637,quinta-feira,15.0,17.0,2.0,p2).
turno(637,leti,2,leti0201).
turno(637,lee,2,lee0202).
turno(637,lee,2,lee0201).
turno(637,leti,2,leti0203).
turno(637,leti,2,leti0202).
turno(637,leti,2,leti0204).
turno(637,leti,3,leti0303).
turno(637,leti,3,leti0302).
turno(637,leti,3,leti0301).
evento(638,'introducao aos circuitos e sistemas electronicos',problemas,52,'1-2').
horario(638,segunda-feira,17.5,18.5,1.0,p2).
turno(638,leti,2,leti0201).
turno(638,lee,2,lee0202).
turno(638,lee,2,lee0201).
turno(638,leti,2,leti0203).
turno(638,leti,2,leti0202).
turno(638,leti,2,leti0204).
turno(638,leti,3,leti0303).
turno(638,leti,3,leti0302).
turno(638,leti,3,leti0301).
evento(639,'introducao aos circuitos e sistemas electronicos',problemas,52,'1-2').
horario(639,quinta-feira,10.0,11.0,1.0,p2).
turno(639,leti,2,leti0201).
turno(639,lee,2,lee0202).
turno(639,lee,2,lee0201).
turno(639,leti,2,leti0203).
turno(639,leti,2,leti0202).
turno(639,leti,2,leti0204).
turno(639,leti,3,leti0303).
turno(639,leti,3,leti0302).
turno(639,leti,3,leti0301).
evento(640,'introducao aos circuitos e sistemas electronicos',laboratorial,21,'1-60').
horario(640,terca-feira,17.5,19.5,2.0,p2).
turno(640,leti,2,leti0201).
turno(640,leti,2,leti0203).
turno(640,leti,3,leti0303).
turno(640,leti,3,leti0302).
turno(640,leti,3,leti0301).
evento(641,'introducao aos circuitos e sistemas electronicos',problemas,40,'0-9').
horario(641,quinta-feira,17.0,18.0,1.0,p2).
turno(641,lee,2,lee0202).
turno(641,lee,2,lee0201).
turno(641,leti,2,leti0203).
turno(641,leti,2,leti0202).
turno(641,leti,2,leti0204).
turno(641,leti,3,leti0303).
turno(641,leti,3,leti0302).
turno(641,leti,3,leti0301).
evento(642,'introducao aos circuitos e sistemas electronicos',problemas,40,'0-17').
horario(642,segunda-feira,18.5,19.5,1.0,p2).
turno(642,lee,2,lee0202).
turno(642,lee,2,lee0201).
turno(642,leti,2,leti0203).
turno(642,leti,2,leti0202).
turno(642,leti,2,leti0204).
turno(642,leti,3,leti0303).
turno(642,leti,3,leti0302).
turno(642,leti,3,leti0301).
evento(643,'introducao aos circuitos e sistemas electronicos',laboratorial,20,'1-60').
horario(643,segunda-feira,16.5,18.5,2.0,p2).
turno(643,lee,2,lee0201).
evento(644,'introducao aos circuitos e sistemas electronicos',laboratorial,21,'1-60').
horario(644,quarta-feira,12.5,14.5,2.0,p2).
turno(644,leti,2,leti0201).
turno(644,leti,2,leti0203).
turno(644,leti,2,leti0202).
turno(644,leti,2,leti0204).
turno(644,leti,3,leti0303).
turno(644,leti,3,leti0302).
turno(644,leti,3,leti0301).
evento(645,'introducao aos circuitos e sistemas electronicos',problemas,40,'0-17').
horario(645,quarta-feira,15.5,16.5,1.0,p2).
turno(645,leti,2,leti0201).
turno(645,leti,2,leti0203).
turno(645,leti,2,leti0202).
turno(645,leti,2,leti0204).
turno(645,leti,3,leti0303).
turno(645,leti,3,leti0302).
turno(645,leti,3,leti0301).
evento(646,'introducao aos circuitos e sistemas electronicos',problemas,40,'0-17').
horario(646,quinta-feira,11.0,12.0,1.0,p2).
turno(646,leti,2,leti0201).
turno(646,leti,2,leti0203).
turno(646,leti,2,leti0202).
turno(646,leti,2,leti0204).
turno(646,leti,3,leti0303).
turno(646,leti,3,leti0302).
turno(646,leti,3,leti0301).
evento(647,'introducao aos circuitos e sistemas electronicos',laboratorial,21,'1-60').
horario(647,sexta-feira,17.5,19.5,2.0,p2).
turno(647,leti,2,leti0201).
turno(647,lee,2,lee0202).
turno(647,lee,2,lee0201).
turno(647,leti,2,leti0203).
turno(647,leti,2,leti0202).
turno(647,leti,2,leti0204).
turno(647,leti,3,leti0303).
turno(647,leti,3,leti0302).
turno(647,leti,3,leti0301).
evento(648,'introducao aos circuitos e sistemas electronicos',laboratorial,21,'1-60').
horario(648,terca-feira,14.5,16.5,2.0,p2).
turno(648,leti,2,leti0202).
turno(648,leti,2,leti0204).
turno(648,leti,3,leti0303).
turno(648,leti,3,leti0302).
turno(648,leti,3,leti0301).
evento(649,'processos de fabrico',problemas,29,'0-15').
horario(649,quinta-feira,10.0,12.0,2.0,p1).
turno(649,legi,3,legi0304).
turno(649,legi,3,legi0301).
evento(650,'processos de fabrico',problemas,13,'1-4').
horario(650,terca-feira,11.0,13.0,2.0,p1).
turno(650,legi,3,legi0303).
evento(651,'processos de fabrico',teorica,63,a3).
horario(651,segunda-feira,9.0,11.0,2.0,p1).
turno(651,legi,3,legi0303).
turno(651,legi,3,legi0304).
turno(651,legi,3,legi0301).
turno(651,legi,3,legi0305).
turno(651,legi,3,legi0302).
evento(652,'processos de fabrico',teorica,63,a3).
horario(652,quinta-feira,8.0,10.0,2.0,p1).
turno(652,legi,3,legi0303).
turno(652,legi,3,legi0304).
turno(652,legi,3,legi0301).
turno(652,legi,3,legi0305).
turno(652,legi,3,legi0302).
evento(653,'processos de fabrico',problemas,19,'1-2').
horario(653,quarta-feira,8.5,10.5,2.0,p1).
turno(653,legi,3,legi0305).
turno(653,legi,3,legi0302).
evento(654,'empreendedorismo de base tecnologica',pratica,57,'0-65').
horario(654,sexta-feira,10.0,12.5,2.5,p1_2).
turno(654,megi,2,megi0202).
turno(654,megi,2,megi0201).
evento(655,'empreendedorismo de base tecnologica',teorica,58,a4).
horario(655,sexta-feira,9.0,10.0,1.0,p1_2).
turno(655,megi,2,megi0202).
turno(655,megi,2,megi0201).
evento(656,'arquitecturas de redes',laboratorial,21,'1-30').
horario(656,segunda-feira,9.0,12.0,3.0,p2).
turno(656,leti,3,leti0303).
turno(656,leti,3,leti0301).
evento(657,'arquitecturas de redes',teorica,67,a2).
horario(657,sexta-feira,13.0,15.0,2.0,p2).
turno(657,leti,3,leti0303).
turno(657,leti,3,leti0302).
turno(657,leti,3,leti0301).
evento(658,'arquitecturas de redes',teorica,67,a3).
horario(658,segunda-feira,14.5,16.5,2.0,p2).
turno(658,leti,3,leti0303).
turno(658,leti,3,leti0302).
turno(658,leti,3,leti0301).
evento(659,'arquitecturas de redes',laboratorial,21,'1-30').
horario(659,quarta-feira,9.0,12.0,3.0,p2).
turno(659,leti,3,leti0303).
turno(659,leti,3,leti0301).
evento(660,'arquitecturas de redes',laboratorial,21,'1-30').
horario(660,terca-feira,9.5,12.5,3.0,p2).
turno(660,leti,3,leti0302).
evento(661,'desafios globais',teorica,129,a1).
horario(661,quarta-feira,11.0,12.5,1.5,p3_4).
evento(662,'desafios globais',teorica,129,a1).
horario(662,quinta-feira,17.0,19.0,2.0,p3_4).
evento(663,'computacao movel e ubiqua',laboratorial,0,'0-27').
horario(663,quinta-feira,8.5,11.5,3.0,p4).
turno(663,meti,1,merc0101).
turno(663,'meic-t',1,meic-t0101).
evento(664,'computacao movel e ubiqua',teorica,30,'0-65').
horario(664,quinta-feira,13.5,15.5,2.0,p4).
turno(664,meti,1,merc0101).
turno(664,'meic-t',1,meic-t0101).
evento(665,'computacao movel e ubiqua',teorica,30,a3).
horario(665,terca-feira,15.5,17.5,2.0,p4).
turno(665,meti,1,merc0101).
turno(665,'meic-t',1,meic-t0101).
evento(666,'computacao movel e ubiqua',laboratorial,0,'0-27').
horario(666,quinta-feira,15.5,18.5,3.0,p4).
turno(666,meti,1,merc0101).
turno(666,'meic-t',1,meic-t0101).
evento(667,'avaliacao de projetos',pratica,14,'0-25').
horario(667,quarta-feira,16.0,17.0,1.0,p3).
turno(667,legi,3,legi0305).
evento(668,'avaliacao de projetos',teorica,57,a5).
horario(668,segunda-feira,13.0,14.0,1.0,p3).
turno(668,legi,3,legi0305).
turno(668,legi,3,legi0304).
turno(668,legi,3,legi0302).
turno(668,legi,3,legi0301).
turno(668,legi,3,legi0303).
evento(669,'avaliacao de projetos',teorica,57,a2).
horario(669,quarta-feira,14.0,16.0,2.0,p3).
turno(669,legi,3,legi0305).
turno(669,legi,3,legi0304).
turno(669,legi,3,legi0302).
turno(669,legi,3,legi0301).
turno(669,legi,3,legi0303).
evento(670,'avaliacao de projetos',pratica,40,'0-25').
horario(670,quarta-feira,13.0,14.0,1.0,p3).
turno(670,legi,3,legi0302).
evento(671,'mecanica e ondas',teorica,71,a5).
horario(671,segunda-feira,11.0,13.0,2.0,p3).
turno(671,leti,1,leti0104).
turno(671,leti,1,leti0102).
turno(671,leti,1,leti0101).
turno(671,leti,1,leti0103).
evento(672,'mecanica e ondas',teorica,71,a5).
horario(672,quinta-feira,12.5,14.5,2.0,p3).
turno(672,leti,1,leti0104).
turno(672,leti,1,leti0102).
turno(672,leti,1,leti0101).
turno(672,leti,1,leti0103).
evento(673,'mecanica e ondas',problemas,37,'0-25').
horario(673,segunda-feira,8.5,10.0,1.5,p3).
turno(673,leti,1,leti0101).
turno(673,leti,1,leti0103).
evento(674,'mecanica e ondas',problemas,37,'0-16').
horario(674,terca-feira,11.5,13.0,1.5,p3).
turno(674,leti,1,leti0101).
turno(674,leti,1,leti0103).
evento(675,'mecanica e ondas',problemas,33,'0-9').
horario(675,terca-feira,15.0,16.5,1.5,p3).
turno(675,leti,1,leti0104).
turno(675,leti,1,leti0102).
evento(676,'mecanica e ondas',problemas,33,'0-17').
horario(676,segunda-feira,13.0,14.5,1.5,p3).
turno(676,leti,1,leti0104).
turno(676,leti,1,leti0102).
evento(677,'bioengenharia de celulas estaminais',problemas,10,'1-2').
horario(677,quarta-feira,10.0,12.0,2.0,p3).
turno(677,mbmrp,1,mbmrp0103).
turno(677,mbmrp,1,mbmrp0102).
turno(677,mbmrp,1,mbmrp0101).
evento(678,'bioengenharia de celulas estaminais',seminario,10,'1-2').
horario(678,terca-feira,11.0,12.0,1.0,p3).
turno(678,mbmrp,1,mbmrp0103).
turno(678,mbmrp,1,mbmrp0102).
turno(678,mbmrp,1,mbmrp0101).
evento(679,'bioengenharia de celulas estaminais',teorica,10,'1-2').
horario(679,terca-feira,10.0,11.0,1.0,p3).
turno(679,mbmrp,1,mbmrp0103).
turno(679,mbmrp,1,mbmrp0102).
turno(679,mbmrp,1,mbmrp0101).
evento(680,'bioengenharia de celulas estaminais',teorica,10,'1-2').
horario(680,segunda-feira,10.0,12.0,2.0,p3).
turno(680,mbmrp,1,mbmrp0103).
turno(680,mbmrp,1,mbmrp0102).
turno(680,mbmrp,1,mbmrp0101).
evento(681,'redes opticas',teorica,12,a3).
horario(681,quinta-feira,15.0,17.0,2.0,p3).
turno(681,mee,1,mee0101).
turno(681,meti,1,merc0101).
evento(682,'redes opticas',teorica,12,a2).
horario(682,terca-feira,15.0,17.0,2.0,p3).
turno(682,mee,1,mee0101).
turno(682,meti,1,merc0101).
evento(683,'redes opticas',problemas,12,'1-11').
horario(683,quinta-feira,17.0,19.0,2.0,p3).
turno(683,mee,1,mee0101).
turno(683,meti,1,merc0101).
evento(684,'redes opticas',problemas,12,'1-11').
horario(684,terca-feira,17.0,19.0,2.0,p3).
turno(684,mee,1,mee0101).
turno(684,meti,1,merc0101).
evento(685,'gestao da qualidade e seguranca',problemas,20,'1-2').
horario(685,terca-feira,16.5,18.0,1.5,p3).
turno(685,legi,3,legi0303).
evento(686,'gestao da qualidade e seguranca',problemas,20,'0-23').
horario(686,quinta-feira,14.0,15.5,1.5,p3).
turno(686,legi,3,legi0303).
evento(687,'gestao da qualidade e seguranca',teorica,63,a5).
horario(687,terca-feira,10.0,12.0,2.0,p3).
turno(687,legi,3,legi0305).
turno(687,legi,3,legi0304).
turno(687,legi,3,legi0302).
turno(687,legi,3,legi0301).
turno(687,legi,3,legi0303).
evento(688,'gestao da qualidade e seguranca',teorica,63,a1).
horario(688,quinta-feira,10.0,12.0,2.0,p3).
turno(688,legi,3,legi0305).
turno(688,legi,3,legi0304).
turno(688,legi,3,legi0302).
turno(688,legi,3,legi0301).
turno(688,legi,3,legi0303).
evento(689,'gestao da qualidade e seguranca',problemas,40,'0-9').
horario(689,quinta-feira,15.5,17.0,1.5,p3).
turno(689,legi,3,legi0305).
turno(689,legi,3,legi0304).
evento(690,'gestao da qualidade e seguranca',problemas,40,'0-17').
horario(690,terca-feira,15.0,16.5,1.5,p3).
turno(690,legi,3,legi0305).
turno(690,legi,3,legi0304).
evento(691,compiladores,problemas,12,'0-23').
horario(691,quinta-feira,8.5,10.0,1.5,p4).
turno(691,'leic-t',3,leic-t0304).
evento(692,compiladores,problemas,12,'0-23').
horario(692,segunda-feira,13.0,14.5,1.5,p4).
turno(692,'leic-t',3,leic-t0304).
evento(693,compiladores,problemas,22,'0-15').
horario(693,sexta-feira,8.0,9.5,1.5,p4).
turno(693,'leic-t',3,leic-t0302).
evento(694,compiladores,problemas,22,'0-15').
horario(694,terca-feira,10.0,11.5,1.5,p4).
turno(694,'leic-t',3,leic-t0302).
evento(695,compiladores,teorica,91,a4).
horario(695,sexta-feira,10.0,12.0,2.0,p4).
turno(695,'leic-t',3,leic-t0304).
turno(695,'leic-t',3,leic-t0306).
turno(695,'leic-t',3,leic-t0305).
turno(695,'leic-t',3,leic-t0301).
turno(695,'leic-t',3,leic-t0303).
turno(695,'leic-t',3,leic-t0302).
evento(696,compiladores,teorica,91,a3).
horario(696,terca-feira,8.0,10.0,2.0,p4).
turno(696,'leic-t',3,leic-t0304).
turno(696,'leic-t',3,leic-t0306).
turno(696,'leic-t',3,leic-t0305).
turno(696,'leic-t',3,leic-t0301).
turno(696,'leic-t',3,leic-t0303).
turno(696,'leic-t',3,leic-t0302).
evento(697,compiladores,problemas,22,'0-23').
horario(697,segunda-feira,8.0,9.5,1.5,p4).
turno(697,'leic-t',3,leic-t0306).
turno(697,'leic-t',3,leic-t0301).
evento(698,compiladores,problemas,22,'0-23').
horario(698,quarta-feira,10.0,11.5,1.5,p4).
turno(698,'leic-t',3,leic-t0306).
turno(698,'leic-t',3,leic-t0301).
evento(699,compiladores,problemas,19,'0-23').
horario(699,segunda-feira,11.5,13.0,1.5,p4).
turno(699,'leic-t',3,leic-t0303).
evento(700,compiladores,problemas,19,'0-23').
horario(700,quinta-feira,12.0,13.5,1.5,p4).
turno(700,'leic-t',3,leic-t0303).
evento(701,compiladores,problemas,17,'0-23').
horario(701,quarta-feira,11.5,13.0,1.5,p4).
turno(701,'leic-t',3,leic-t0305).
evento(702,compiladores,problemas,17,'0-15').
horario(702,terca-feira,11.5,13.0,1.5,p4).
turno(702,'leic-t',3,leic-t0305).
evento(703,'engenharia de software',teorica,54,a4).
horario(703,sexta-feira,12.5,14.5,2.0,p3).
turno(703,leti,3,leti0301).
turno(703,leti,3,leti0302).
turno(703,leti,3,leti0303).
evento(704,'engenharia de software',teorica,54,a3).
horario(704,segunda-feira,10.0,12.0,2.0,p3).
turno(704,leti,3,leti0301).
turno(704,leti,3,leti0302).
turno(704,leti,3,leti0303).
evento(705,'engenharia de software',laboratorial,24,'1-19').
horario(705,segunda-feira,10.0,11.5,1.5,p3).
turno(705,'leic-t',3,leic-t0304).
turno(705,'leic-t',3,leic-t0302).
evento(706,'engenharia de software',laboratorial,24,'1-27').
horario(706,quinta-feira,8.5,10.0,1.5,p3).
turno(706,'leic-t',3,leic-t0304).
turno(706,'leic-t',3,leic-t0302).
evento(707,'engenharia de software',laboratorial,24,'1-15').
horario(707,segunda-feira,12.0,13.5,1.5,p3).
turno(707,leti,3,leti0302).
turno(707,'leic-t',3,leic-t0301).
evento(708,'engenharia de software',laboratorial,24,'1-15').
horario(708,terca-feira,11.5,13.0,1.5,p3).
turno(708,leti,3,leti0302).
turno(708,'leic-t',3,leic-t0301).
evento(709,'engenharia de software',laboratorial,24,'0-14').
horario(709,sexta-feira,9.5,11.0,1.5,p3).
turno(709,leti,3,leti0301).
evento(710,'engenharia de software',laboratorial,24,'0-14').
horario(710,segunda-feira,8.5,10.0,1.5,p3).
turno(710,leti,3,leti0301).
evento(711,'engenharia de software',laboratorial,24,'1-15').
horario(711,quarta-feira,11.5,13.0,1.5,p3).
turno(711,'leic-t',3,leic-t0303).
evento(712,'engenharia de software',laboratorial,24,'1-15').
horario(712,segunda-feira,10.0,11.5,1.5,p3).
turno(712,'leic-t',3,leic-t0303).
evento(713,'engenharia de software',laboratorial,23,'1-19').
horario(713,quinta-feira,10.0,11.5,1.5,p3).
turno(713,leti,3,leti0303).
evento(714,'engenharia de software',laboratorial,23,'1-19').
horario(714,segunda-feira,8.5,10.0,1.5,p3).
turno(714,leti,3,leti0303).
evento(715,'engenharia de software',laboratorial,24,'1-17').
horario(715,quinta-feira,8.5,10.0,1.5,p3).
turno(715,'leic-t',3,leic-t0306).
evento(716,'engenharia de software',laboratorial,24,'0-21').
horario(716,terca-feira,10.0,11.5,1.5,p3).
turno(716,'leic-t',3,leic-t0306).
evento(717,'engenharia de software',laboratorial,18,'1-15').
horario(717,terca-feira,10.0,11.5,1.5,p3).
turno(717,'leic-t',3,leic-t0305).
evento(718,'engenharia de software',laboratorial,18,'1-29').
horario(718,segunda-feira,11.5,13.0,1.5,p3).
turno(718,'leic-t',3,leic-t0305).
evento(719,'engenharia de software',teorica,96,a3).
horario(719,sexta-feira,10.5,12.5,2.0,p3).
turno(719,'leic-t',3,leic-t0304).
turno(719,'leic-t',3,leic-t0306).
turno(719,'leic-t',3,leic-t0305).
turno(719,'leic-t',3,leic-t0301).
turno(719,'leic-t',3,leic-t0303).
turno(719,'leic-t',3,leic-t0302).
evento(720,'engenharia de software',teorica,96,a3).
horario(720,segunda-feira,8.0,10.0,2.0,p3).
turno(720,'leic-t',3,leic-t0304).
turno(720,'leic-t',3,leic-t0306).
turno(720,'leic-t',3,leic-t0305).
turno(720,'leic-t',3,leic-t0301).
turno(720,'leic-t',3,leic-t0303).
turno(720,'leic-t',3,leic-t0302).
evento(721,'estrategia empresarial',problemas,36,'0-25').
horario(721,terca-feira,14.0,15.5,1.5,p3).
turno(721,megi,1,megi0102).
evento(722,'estrategia empresarial',problemas,36,'0-15').
horario(722,segunda-feira,14.0,15.5,1.5,p3).
turno(722,megi,1,megi0102).
evento(723,'estrategia empresarial',teorica,116,a2).
horario(723,terca-feira,11.5,13.0,1.5,p3).
turno(723,megi,1,megi0103).
turno(723,megi,1,megi0101).
turno(723,megi,1,megi0102).
evento(724,'estrategia empresarial',teorica,116,a2).
horario(724,segunda-feira,11.5,13.0,1.5,p3).
turno(724,megi,1,megi0103).
turno(724,megi,1,megi0101).
turno(724,megi,1,megi0102).
evento(725,'estrategia empresarial',problemas,37,'0-16').
horario(725,terca-feira,10.0,11.5,1.5,p3).
turno(725,megi,1,megi0101).
evento(726,'estrategia empresarial',problemas,37,'0-9').
horario(726,segunda-feira,10.0,11.5,1.5,p3).
turno(726,megi,1,megi0101).
evento(727,'estrategia empresarial',problemas,29,'0-73').
horario(727,terca-feira,15.5,17.0,1.5,p3).
turno(727,megi,1,megi0103).
evento(728,'estrategia empresarial',problemas,29,'0-25').
horario(728,segunda-feira,15.5,17.0,1.5,p3).
turno(728,megi,1,megi0103).
evento(729,'computacao em nuvem e virtualizacao',teorica,22,a4).
horario(729,terca-feira,8.5,10.5,2.0,p4).
turno(729,meti,1,merc0101).
turno(729,'meic-t',1,meic-t0101).
evento(730,'computacao em nuvem e virtualizacao',teorica,22,'1-24').
horario(730,quinta-feira,15.5,17.5,2.0,p4).
turno(730,meti,1,merc0101).
turno(730,'meic-t',1,meic-t0101).
evento(731,'computacao em nuvem e virtualizacao',laboratorial,0,'1-17').
horario(731,sexta-feira,8.5,11.5,3.0,p4).
turno(731,'meic-t',1,meic-t0101).
evento(732,'computacao em nuvem e virtualizacao',laboratorial,0,'1-17').
horario(732,quarta-feira,8.5,11.5,3.0,p4).
turno(732,meti,1,merc0101).
turno(732,'meic-t',1,meic-t0101).
evento(733,'introducao aos sistemas de energia eletrica',teorica,100,a4).
horario(733,segunda-feira,14.5,16.5,2.0,p4).
turno(733,legi,2,legi0204).
turno(733,legi,2,legi0202).
turno(733,legi,2,legi0205).
turno(733,legi,2,legi0203).
turno(733,legi,2,legi0201).
evento(734,'introducao aos sistemas de energia eletrica',teorica,100,a4).
horario(734,sexta-feira,14.5,16.5,2.0,p4).
turno(734,legi,2,legi0204).
turno(734,legi,2,legi0202).
turno(734,legi,2,legi0205).
turno(734,legi,2,legi0203).
turno(734,legi,2,legi0201).
evento(735,'introducao aos sistemas de energia eletrica',teorica,100,a4).
horario(735,quinta-feira,14.5,16.5,2.0,p4).
turno(735,legi,2,legi0204).
turno(735,legi,2,legi0202).
turno(735,legi,2,legi0205).
turno(735,legi,2,legi0203).
turno(735,legi,2,legi0201).
evento(736,'introducao aos sistemas de energia eletrica',problemas,40,'1-3').
horario(736,sexta-feira,12.5,14.5,2.0,p4).
turno(736,legi,2,legi0205).
turno(736,legi,2,legi0201).
evento(737,'introducao aos sistemas de energia eletrica',problemas,40,'1-3').
horario(737,sexta-feira,16.5,18.5,2.0,p4).
turno(737,legi,2,legi0204).
turno(737,legi,2,legi0202).
evento(738,'introducao aos sistemas de energia eletrica',problemas,20,'0-25').
horario(738,quinta-feira,16.5,18.5,2.0,p4).
turno(738,legi,2,legi0203).
evento(739,'fisica  com laboratorio',laboratorial,21,'1-14').
horario(739,terca-feira,8.0,10.0,2.0,p3).
turno(739,lee,1,lee0101).
turno(739,lee,1,lee0103).
evento(740,'fisica  com laboratorio',problemas,29,'0-25').
horario(740,quinta-feira,11.0,12.0,1.0,p3).
turno(740,lee,1,lee0101).
turno(740,lee,1,lee0103).
evento(741,'fisica  com laboratorio',laboratorial,21,'1-14').
horario(741,quinta-feira,12.5,14.5,2.0,p3).
turno(741,lee,1,lee0102).
evento(742,'fisica  com laboratorio',teorica,42,'1-22').
horario(742,segunda-feira,10.0,12.0,2.0,p3).
turno(742,lee,1,lee0101).
turno(742,lee,1,lee0102).
turno(742,lee,1,lee0103).
evento(743,'fisica  com laboratorio',teorica,42,'1-24').
horario(743,segunda-feira,10.5,12.5,2.0,indeterminado).
turno(743,lee,1,lee0101).
turno(743,lee,1,lee0102).
turno(743,lee,1,lee0103).
evento(744,'seguranca e gestao de sistemas de informacao',seminario,77,a2).
horario(744,quarta-feira,14.5,17.5,3.0,p4).
turno(744,'meic-t',1,meic-t0101).
evento(745,'seguranca e gestao de sistemas de informacao',seminario,58,a5).
horario(745,quinta-feira,12.5,15.5,3.0,p4).
turno(745,'meic-t',1,meic-t0101).
evento(746,'planeamento e controlo de operacoes','teorico-pratica',21,'1-2').
horario(746,quarta-feira,15.5,17.5,2.0,indeterminado).
turno(746,megi,1,megi0102).
evento(747,'planeamento e controlo de operacoes','teorico-pratica',21,'0-16').
horario(747,segunda-feira,15.5,17.5,2.0,p3).
turno(747,megi,1,megi0102).
evento(748,'planeamento e controlo de operacoes','teorico-pratica',21,'0-75').
horario(748,terca-feira,15.5,17.5,2.0,p3).
turno(748,megi,1,megi0102).
evento(749,'planeamento e controlo de operacoes','teorico-pratica',21,'0-16').
horario(749,quarta-feira,15.5,17.5,2.0,p3).
turno(749,megi,1,megi0102).
evento(750,'planeamento e controlo de operacoes','teorico-pratica',44,'1-3').
horario(750,terca-feira,13.5,15.5,2.0,indeterminado).
turno(750,megi,1,megi0103).
turno(750,megi,1,megi0101).
evento(751,'planeamento e controlo de operacoes','teorico-pratica',44,a4).
horario(751,quarta-feira,13.5,15.5,2.0,p3).
turno(751,megi,1,megi0103).
turno(751,megi,1,megi0101).
evento(752,'planeamento e controlo de operacoes','teorico-pratica',44,'0-75').
horario(752,terca-feira,13.5,15.5,2.0,p3).
turno(752,megi,1,megi0103).
turno(752,megi,1,megi0101).
evento(753,'planeamento e controlo de operacoes','teorico-pratica',44,'0-65').
horario(753,segunda-feira,13.5,15.5,2.0,p3).
turno(753,megi,1,megi0103).
turno(753,megi,1,megi0101).
evento(754,'matematica computacional','teorico-pratica',40,'1-22').
horario(754,quarta-feira,12.0,14.0,2.0,p3_4).
turno(754,legi,2,legi0204).
turno(754,legi,2,legi0202).
evento(755,'matematica computacional','teorico-pratica',40,'1-3').
horario(755,terca-feira,11.5,13.5,2.0,p3_4).
turno(755,legi,2,legi0204).
turno(755,legi,2,legi0202).
evento(756,'matematica computacional','teorico-pratica',59,'1-4').
horario(756,quarta-feira,15.0,17.0,2.0,p3_4).
turno(756,legi,2,legi0205).
turno(756,legi,2,legi0203).
turno(756,legi,2,legi0201).
evento(757,'matematica computacional','teorico-pratica',59,'1-22').
horario(757,terca-feira,14.5,16.5,2.0,p3_4).
turno(757,legi,2,legi0205).
turno(757,legi,2,legi0203).
turno(757,legi,2,legi0201).
evento(758,'instrumentacao e aquisicao de sinais',laboratorial,12,'1-64').
horario(758,segunda-feira,13.0,16.0,3.0,p4).
turno(758,lee,3,lee0302).
evento(759,'instrumentacao e aquisicao de sinais','teorico-pratica',35,'0-73').
horario(759,terca-feira,10.0,12.0,2.0,p4).
turno(759,lee,3,lee0302).
turno(759,lee,3,lee0301).
evento(760,'instrumentacao e aquisicao de sinais','teorico-pratica',35,'0-73').
horario(760,segunda-feira,10.0,12.0,2.0,p4).
turno(760,lee,3,lee0302).
turno(760,lee,3,lee0301).
evento(761,'instrumentacao e aquisicao de sinais',laboratorial,18,'1-64').
horario(761,sexta-feira,9.5,12.5,3.0,p4).
turno(761,lee,3,lee0301).
evento(762,'inteligencia artificial',laboratorial,24,'1-19').
horario(762,quinta-feira,14.5,16.0,1.5,p4).
turno(762,'leic-t',2,leic-t0203).
evento(763,'inteligencia artificial',laboratorial,24,'1-19').
horario(763,sexta-feira,13.5,15.0,1.5,p4).
turno(763,'leic-t',2,leic-t0203).
evento(764,'inteligencia artificial',laboratorial,23,'0-27').
horario(764,sexta-feira,12.5,14.0,1.5,p3).
turno(764,'leic-t',3,leic-t0302).
evento(765,'inteligencia artificial',laboratorial,23,'1-19').
horario(765,segunda-feira,11.5,13.0,1.5,p3).
turno(765,'leic-t',3,leic-t0302).
evento(766,'inteligencia artificial',laboratorial,24,'1-17').
horario(766,terca-feira,14.0,15.5,1.5,p4).
turno(766,'leic-t',2,leic-t0201).
evento(767,'inteligencia artificial',laboratorial,24,'1-29').
horario(767,sexta-feira,13.5,15.0,1.5,p4).
turno(767,'leic-t',2,leic-t0201).
evento(768,'inteligencia artificial',laboratorial,24,'1-17').
horario(768,sexta-feira,15.5,17.0,1.5,p4).
turno(768,'leic-t',2,leic-t0204).
evento(769,'inteligencia artificial',laboratorial,24,'1-19').
horario(769,segunda-feira,14.5,16.0,1.5,p4).
turno(769,'leic-t',2,leic-t0204).
evento(770,'inteligencia artificial',laboratorial,0,'1-17').
horario(770,quarta-feira,15.0,16.5,1.5,p4).
turno(770,'leic-t',2,leic-t0205).
evento(771,'inteligencia artificial',laboratorial,0,'1-15').
horario(771,sexta-feira,17.0,18.5,1.5,p4).
turno(771,'leic-t',2,leic-t0205).
evento(772,'inteligencia artificial',teorica,101,a5).
horario(772,quinta-feira,16.0,17.0,1.0,p4).
turno(772,'leic-t',2,leic-t0201).
turno(772,'leic-t',2,leic-t0206).
turno(772,'leic-t',2,leic-t0202).
turno(772,'leic-t',2,leic-t0204).
turno(772,'leic-t',2,leic-t0203).
turno(772,'leic-t',2,leic-t0205).
evento(773,'inteligencia artificial',teorica,101,a5).
horario(773,segunda-feira,16.0,18.0,2.0,p4).
turno(773,'leic-t',2,leic-t0201).
turno(773,'leic-t',2,leic-t0206).
turno(773,'leic-t',2,leic-t0202).
turno(773,'leic-t',2,leic-t0204).
turno(773,'leic-t',2,leic-t0203).
turno(773,'leic-t',2,leic-t0205).
evento(774,'inteligencia artificial',teorica,101,a3).
horario(774,quarta-feira,17.0,19.0,2.0,p4).
turno(774,'leic-t',2,leic-t0201).
turno(774,'leic-t',2,leic-t0206).
turno(774,'leic-t',2,leic-t0202).
turno(774,'leic-t',2,leic-t0204).
turno(774,'leic-t',2,leic-t0203).
turno(774,'leic-t',2,leic-t0205).
evento(775,'inteligencia artificial',laboratorial,16,'1-19').
horario(775,sexta-feira,12.5,14.0,1.5,p3).
turno(775,'leic-t',3,leic-t0304).
evento(776,'inteligencia artificial',laboratorial,16,'0-21').
horario(776,quarta-feira,10.0,11.5,1.5,p3).
turno(776,'leic-t',3,leic-t0304).
evento(777,'inteligencia artificial',laboratorial,21,'0-21').
horario(777,quinta-feira,8.5,10.0,1.5,p3).
turno(777,'leic-t',3,leic-t0303).
evento(778,'inteligencia artificial',laboratorial,21,'1-15').
horario(778,quarta-feira,10.0,11.5,1.5,p3).
turno(778,'leic-t',3,leic-t0303).
evento(779,'inteligencia artificial',laboratorial,0,'1-17').
horario(779,quarta-feira,12.0,13.5,1.5,p3).
turno(779,'leic-t',3,leic-t0306).
turno(779,'leic-t',3,leic-t0301).
evento(780,'inteligencia artificial',laboratorial,0,'1-17').
horario(780,segunda-feira,10.0,11.5,1.5,p3).
turno(780,'leic-t',3,leic-t0306).
turno(780,'leic-t',3,leic-t0301).
evento(781,'inteligencia artificial',laboratorial,23,'1-15').
horario(781,terca-feira,14.0,15.5,1.5,p4).
turno(781,'leic-t',2,leic-t0206).
turno(781,'leic-t',2,leic-t0202).
evento(782,'inteligencia artificial',laboratorial,23,'1-15').
horario(782,sexta-feira,14.0,15.5,1.5,p4).
turno(782,'leic-t',2,leic-t0206).
turno(782,'leic-t',2,leic-t0202).
evento(783,'inteligencia artificial',teorica,82,a3).
horario(783,sexta-feira,8.0,10.0,2.0,p3).
turno(783,'leic-t',3,leic-t0304).
turno(783,'leic-t',3,leic-t0306).
turno(783,'leic-t',3,leic-t0305).
turno(783,'leic-t',3,leic-t0301).
turno(783,'leic-t',3,leic-t0303).
turno(783,'leic-t',3,leic-t0302).
evento(784,'inteligencia artificial',teorica,82,a3).
horario(784,terca-feira,8.5,9.5,1.0,p3).
turno(784,'leic-t',3,leic-t0304).
turno(784,'leic-t',3,leic-t0306).
turno(784,'leic-t',3,leic-t0305).
turno(784,'leic-t',3,leic-t0301).
turno(784,'leic-t',3,leic-t0303).
turno(784,'leic-t',3,leic-t0302).
evento(785,'inteligencia artificial',teorica,82,a3).
horario(785,quarta-feira,8.0,10.0,2.0,p3).
turno(785,'leic-t',3,leic-t0304).
turno(785,'leic-t',3,leic-t0306).
turno(785,'leic-t',3,leic-t0305).
turno(785,'leic-t',3,leic-t0301).
turno(785,'leic-t',3,leic-t0303).
turno(785,'leic-t',3,leic-t0302).
evento(786,'inteligencia artificial',laboratorial,24,'1-15').
horario(786,sexta-feira,12.5,14.0,1.5,p3).
turno(786,'leic-t',3,leic-t0305).
evento(787,'inteligencia artificial',laboratorial,24,'0-14').
horario(787,segunda-feira,10.0,11.5,1.5,p3).
turno(787,'leic-t',3,leic-t0305).
evento(788,'tecnologias de informacao e decisao biomedica',teorica,8,'0-13').
horario(788,terca-feira,14.5,16.5,2.0,p3).
turno(788,mbmrp,1,mbmrp0103).
turno(788,mbmrp,1,mbmrp0102).
turno(788,mbmrp,1,mbmrp0101).
evento(789,'tecnologias de informacao e decisao biomedica',teorica,8,'0-13').
horario(789,quinta-feira,14.5,16.5,2.0,p3).
turno(789,mbmrp,1,mbmrp0103).
turno(789,mbmrp,1,mbmrp0102).
turno(789,mbmrp,1,mbmrp0101).
evento(790,'tecnologias de informacao e decisao biomedica',laboratorial,11,'1-17').
horario(790,sexta-feira,14.5,17.5,3.0,p3).
turno(790,mbmrp,1,mbmrp0103).
turno(790,mbmrp,1,mbmrp0102).
turno(790,mbmrp,1,mbmrp0101).
evento(791,'agentes autonomos e sistemas multi-agente',laboratorial,23,'0-17').
horario(791,sexta-feira,9.0,12.0,3.0,p4).
turno(791,'meic-t',1,meic-t0101).
evento(792,'agentes autonomos e sistemas multi-agente',laboratorial,30,'0-73').
horario(792,quinta-feira,9.0,12.0,3.0,p4).
turno(792,'meic-t',1,meic-t0101).
evento(793,'agentes autonomos e sistemas multi-agente',teorica,43,a5).
horario(793,quarta-feira,9.5,11.5,2.0,p4).
turno(793,'meic-t',1,meic-t0101).
evento(794,'agentes autonomos e sistemas multi-agente',teorica,43,a5).
horario(794,terca-feira,10.5,12.5,2.0,p4).
turno(794,'meic-t',1,meic-t0101).
evento(795,'agentes autonomos e sistemas multi-agente',laboratorial,0,'0-73').
horario(795,sexta-feira,12.5,15.5,3.0,p4).
turno(795,'meic-t',1,meic-t0101).
evento(796,'tecnologia dos biomateriais',problemas,9,'1-2').
horario(796,segunda-feira,15.0,16.5,1.5,p3).
turno(796,mbmrp,1,mbmrp0103).
turno(796,mbmrp,1,mbmrp0102).
turno(796,mbmrp,1,mbmrp0101).
evento(797,'tecnologia dos biomateriais',laboratorial,9,'1-15').
horario(797,quarta-feira,13.0,16.0,3.0,p3).
turno(797,mbmrp,1,mbmrp0103).
turno(797,mbmrp,1,mbmrp0102).
turno(797,mbmrp,1,mbmrp0101).
evento(798,'tecnologia dos biomateriais',laboratorial,9,'0-9').
horario(798,quarta-feira,13.0,16.0,3.0,p3).
turno(798,mbmrp,1,mbmrp0103).
turno(798,mbmrp,1,mbmrp0102).
turno(798,mbmrp,1,mbmrp0101).
evento(799,'tecnologia dos biomateriais',seminario,9,'0-25').
horario(799,segunda-feira,13.0,15.0,2.0,p3).
turno(799,mbmrp,1,mbmrp0103).
turno(799,mbmrp,1,mbmrp0102).
turno(799,mbmrp,1,mbmrp0101).
evento(800,'ciencia de materiais',teorica,95,a2).
horario(800,quinta-feira,8.0,10.0,2.0,p3).
turno(800,legi,1,legi0101).
turno(800,legi,1,legi0104).
turno(800,legi,1,legi0105).
turno(800,legi,1,legi0102).
turno(800,legi,1,legi0103).